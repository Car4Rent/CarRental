package com.spectrum.car4rent;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.util.List;

public class Car__details extends AppCompatActivity {
    private List<CarView> listData;

    private RecyclerView rvcardetails;
    public RelativeLayout root;
    public TextView CarTitle, CarMileage, CarFuel, CarYear, CarCompany, CarRenthr,CarRentday,CarAc,CarColor,CarRegno,CarSeat,CarSpare;
    public ImageView CarImage;
    Button book;
    int popular;
    String carOwner;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        String bgcolor = "#1B1B6B";
        ActionBar actionBar = getSupportActionBar();
        actionBar.setBackgroundDrawable(new ColorDrawable(Color.parseColor(bgcolor)));
        actionBar.setTitle("");
        actionBar.setDisplayHomeAsUpEnabled(true);
        this.getWindow().setStatusBarColor(Color.parseColor(bgcolor));


        setContentView(R.layout.car_details);

        Intent j=getIntent();
        final String id=j.getStringExtra("key");
        final Boolean re=j.getBooleanExtra("reg",false);
        Log.d("Home", "starting fetch");
        Log.e("Key",id+""+re);

        CarTitle = findViewById(R.id.car_details_title);
        CarImage = findViewById(R.id.car_details_image);
        CarFuel = findViewById(R.id.car_details_fuel);
        CarMileage = findViewById(R.id.car_details_mileage);
        CarRenthr = findViewById(R.id.car_details_hrprice);
        CarRentday=findViewById(R.id.car_details_dayprice);
        CarYear=findViewById(R.id.car_details_year);
        CarAc=findViewById(R.id.car_details_ac);
        CarColor=findViewById(R.id.car_details_color);
        CarCompany=findViewById(R.id.car_details_company);
        CarRegno=findViewById(R.id.car_details_registerno);
        CarSeat=findViewById(R.id.car_details_seat);
        CarSpare=findViewById(R.id.car_details_spare);
        book=findViewById(R.id.car_details_book);

        book.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent book=new Intent(Car__details.this, Booking.class);
                book.putExtra("key",id);
                startActivity(book);

            }
        });

        DatabaseReference nm = FirebaseDatabase.getInstance().getReference("cars/"+id);
        nm.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {

                        CarView ld = dataSnapshot.getValue(CarView.class);
                        carOwner=ld.getUserid();
                        CarTitle.setText(ld.getModel());
                        Picasso.get().load(ld.image).placeholder(R.drawable.dummy_car).fit().centerCrop().into(CarImage);
                        CarFuel.setText(ld.getFuel());
                        CarMileage.setText(ld.getMileage()+" km/ltr");
                        CarRenthr.setText("Rs. " +(ld.getRenthour())+" /hr");
                        CarRentday.setText("Rs. "+(ld.getRentday())+" /day");
                        CarYear.setText(ld.getYear());
                        CarAc.append(" "+ld.getAc());
                        CarColor.append(" "+ld.getColour());
                        CarCompany.setText(ld.getCompany());
                        CarRegno.setText((ld.getRegno()));
                        CarSeat.setText(ld.getSeat());
                        CarSpare.append(" "+ld.getSpare());
                        popular=ld.getPopular();

                    }
                if(!carOwner.equals(FirebaseAuth.getInstance().getCurrentUser().getUid())){

                    FirebaseDatabase.getInstance().getReference("cars/"+id).child("popular").setValue(popular+1);
                }
                switch (CarCompany.getText().toString()){
                    case "Hyundai":
                        findViewById(R.id.car_details_company_logo).setBackgroundResource(R.drawable.hyundai);break;
                    case "Tata":
                        findViewById(R.id.car_details_company_logo).setBackgroundResource(R.drawable.tata);break;
                    case "Mahindra":
                        findViewById(R.id.car_details_company_logo).setBackgroundResource(R.drawable.mahindra);break;
                    case "Honda":
                        findViewById(R.id.car_details_company_logo).setBackgroundResource(R.drawable.honda);break;
                    case "Maruti":
                        findViewById(R.id.car_details_company_logo).setBackgroundResource(R.drawable.maruti);break;
                }
                }


            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        if(!re){
            findViewById(R.id.car_details_reg).setVisibility(View.GONE);
            CarRegno.setVisibility(View.GONE);
        }else{
            findViewById(R.id.car_details_reg).setVisibility(View.VISIBLE);
            CarRegno.setVisibility(View.VISIBLE);
        }

    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

}

