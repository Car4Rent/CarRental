package com.spectrum.car4rent;

import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class PremiumCars extends AppCompatActivity{

    SharedPreferences pref;
    SharedPreferences.Editor editor;
    private FirebaseAuth firebaseAuth;
    FirebaseUser currentUser;
    TextView textView;
    Button sort, filter;

    private RecyclerView rvviewcars;
    private LinearLayoutManager linearLayoutManager;

    private MyAdapter adapter;
    private List<CarView> listData;

    private DatabaseReference databaseReference;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        String bgcolor = "#1B1B6B";
        ActionBar actionBar = getSupportActionBar();
        actionBar.setBackgroundDrawable(new ColorDrawable(Color.parseColor(bgcolor)));
        actionBar.setTitle("");
        actionBar.setDisplayHomeAsUpEnabled(true);
        this.getWindow().setStatusBarColor(Color.parseColor(bgcolor));

        setContentView(R.layout.premium_cars);
/*
        Toolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setBackgroundColor(Color.parseColor(bgcolor));
        setSupportActionBar(toolbar);
*/
        /*FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
*/
        currentUser = FirebaseAuth.getInstance().getCurrentUser();

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);
       /* ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();*/
//TODO        navigationView.setNavigationItemSelectedListener(this);

        firebaseAuth= FirebaseAuth.getInstance();

        pref = getApplicationContext().getSharedPreferences("MyPref", MODE_PRIVATE);
        editor = pref.edit();

        /*View view = navigationView.getHeaderView(0);
        final ImageView pro_pic = view.findViewById(R.id.profile_pic);

        pro_pic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FirebaseUser currentUser = firebaseAuth.getCurrentUser();
                Intent i = new Intent(getApplicationContext(), Profile.class);
                startActivity(i);
            }
        });

        DatabaseReference dref = FirebaseDatabase.getInstance().getReference("User/"+currentUser.getUid()+"/profile/img");

        dref.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                if (snapshot.exists()){
                    Picasso.get().
                            load(snapshot.getValue().toString())
                            .centerCrop()
                            .fit()
                            .into(pro_pic);
                }
            }
            @Override
            public void onCancelled(DatabaseError databaseError) {
            }
        });

        DatabaseReference dref2 = FirebaseDatabase.getInstance().getReference("User/"+currentUser.getUid());
        dref2.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                //Toast.makeText(getApplicationContext(),snapshot.getValue().toString(),Toast.LENGTH_LONG).show();
                Register reg = snapshot.getValue(Register.class);
                textView = findViewById(R.id.textView);
                textView.setText(reg.getName());

            }
            @Override
            public void onCancelled(DatabaseError databaseError) {
            }
        });
*/

        databaseReference = FirebaseDatabase.getInstance().getReference();

    //popular brands
    rvviewcars = findViewById(R.id.home_rv_viewcars);
        linearLayoutManager = new LinearLayoutManager(this);
        rvviewcars.setHasFixedSize(true);
        rvviewcars.setLayoutManager(linearLayoutManager);
        listData=new ArrayList();
        DatabaseReference nm = FirebaseDatabase.getInstance().getReference("cars");

        nm.addListenerForSingleValueEvent(new ValueEventListener() {
            CarView l;
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    for (DataSnapshot npsnapshot : dataSnapshot.getChildren()) {
                        l = npsnapshot.getValue(CarView.class);
                        if(l.getPremium().equals("Yes")) {
                            listData.add(l);
                        }
                    }
                    findViewById(R.id.progress_bar_home).setVisibility(View.GONE);
                    adapter = new MyAdapter(getApplicationContext(),listData,3);
                    rvviewcars.setAdapter(adapter);


                }
                else{
                    findViewById(R.id.textVi).setVisibility(View.VISIBLE);
                    findViewById(R.id.progress_bar_home).setVisibility(View.GONE);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });


    }

/*        filter = (Button) findViewById(R.id.home_btn_filter);


        filter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(Drawer.this, Filter.class);
                startActivity(i);

            }
        });
*/
@Override
public boolean onSupportNavigateUp() {
    onBackPressed();
    return true;
}






}
