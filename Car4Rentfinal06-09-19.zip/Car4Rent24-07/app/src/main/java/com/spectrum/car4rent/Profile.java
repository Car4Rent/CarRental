
package com.spectrum.car4rent;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.StorageTask;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;

import java.io.ByteArrayOutputStream;
import java.util.List;

public class Profile extends AppCompatActivity {

    public static final int MY_PERMISSIONS_REQUEST_CAMERA = 100;

    ProgressDialog progressDialog;
    Button save;
    private List<User_Up> mUploads;

    private ImageView addphoto,propic;
    private TextView Pmail,Pname,Pdob,Pphone;

    private int GALLERY = 1, CAMERA = 2;
    public Uri imguri;
    Bitmap thumbnail;
    boolean flag;

    private FirebaseAuth firebaseAuth;
    private StorageReference mStorageRef;
    private DatabaseReference mDatabaseRef;
    private StorageTask mUploadTAsk;
    FirebaseUser currentUser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        String bgcolor = "#1B1B6B";
        ActionBar actionBar = getSupportActionBar();
        actionBar.setBackgroundDrawable(new ColorDrawable(Color.parseColor(bgcolor)));
        actionBar.setTitle("Profile");
        actionBar.setDisplayHomeAsUpEnabled(true);
        this.getWindow().setStatusBarColor(Color.parseColor(bgcolor));

        setContentView(R.layout.activity_profile);

        firebaseAuth = FirebaseAuth.getInstance();

        currentUser = firebaseAuth.getCurrentUser();

        mDatabaseRef = FirebaseDatabase.getInstance().getReference().child("User/"+currentUser.getUid());
        mStorageRef = FirebaseStorage.getInstance().getReference("Profile/"+currentUser.getUid());

        save = findViewById(R.id.save);
        addphoto = findViewById(R.id.addphoto);
        propic= findViewById(R.id.propic);
        Pname=findViewById(R.id.profile_name);
        Pphone = findViewById(R.id.phoneNumber);
        Pdob=findViewById(R.id.profile_dob);
        Pmail=findViewById(R.id.emailid);
        Pname.setEnabled(false);Pphone.setEnabled(false);Pdob.setEnabled(false);
        addphoto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showPictureDialog();
            }
        });

        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mUploadTAsk != null && mUploadTAsk.isInProgress()){
                    Toast.makeText(getApplicationContext(),"Upload in Progress",Toast.LENGTH_SHORT).show();
                }else {
                    progressDialog = new ProgressDialog(Profile.this);
                    progressDialog.setMessage("Uploading in Progress.....\nPlease Wait....");
                    progressDialog.show();
                    uploadfile();
                }
            }
        });

        DatabaseReference dref = FirebaseDatabase.getInstance().getReference("User/"+currentUser.getUid()+"/profile/img");

        dref.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    Picasso.get().load(snapshot.getValue().toString()).into(propic);
                }
            }
            @Override
            public void onCancelled(DatabaseError databaseError) {
            }
        });

        DatabaseReference dref2 = FirebaseDatabase.getInstance().getReference("User");
        dref2.child(currentUser.getUid()).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                //Toast.makeText(getApplicationContext(),snapshot.getValue().toString(),Toast.LENGTH_LONG).show();
                Register reg = snapshot.getValue(Register.class);
                Pname.setText("  "+reg.getName());
                Pdob.setText("  "+reg.getDob());
                Pmail.setText("  "+reg.getEmail());
                if(!reg.getPhone().isEmpty()) {
                    Pphone.setText("  " + reg.getPhone());
                }else{
                    Pphone.setText("");
                }

                //Toast.makeText(getApplicationContext(),reg.getName(),Toast.LENGTH_LONG).show();
            }
            @Override
            public void onCancelled(DatabaseError databaseError) {
            }
        });


    }
    private void showPictureDialog(){
        AlertDialog.Builder pictureDialog = new AlertDialog.Builder(this);
        pictureDialog.setTitle("Choose your profile picture");
        String[] pictureDialogItems = {
                "Choose photo from gallery",
                "Take a photo From camera","Cancel" };
        pictureDialog.setItems(pictureDialogItems,
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        switch (which) {
                            case 0:
                                choosePhotoFromGallary();
                                break;
                            case 1:
                                if (ContextCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                                    requestPermission();
                                }else {
                                    takePhotoFromCamera();
                                }
                                break;
                            case 2:
                                dialog.dismiss();
                        }
                    }
                });
        pictureDialog.show();
    }
    public void choosePhotoFromGallary() {
        Intent galleryIntent = new Intent(Intent.ACTION_PICK,
                android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(galleryIntent, GALLERY);
    }
    private void takePhotoFromCamera() {
        Intent intent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
        startActivityForResult(intent, CAMERA);
    }
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == this.RESULT_CANCELED) {
            return;
        }
        if (requestCode == GALLERY) {
            if (data != null) {
                imguri = data.getData();
                propic.setImageURI(imguri);
                flag = true;
            }
        } else if (requestCode == CAMERA) {
            thumbnail = (Bitmap) data.getExtras().get("data");
            propic.setImageBitmap(thumbnail);
            flag=false;
        }
        save.setEnabled(true);
    }

    private String getExtension(Uri uri){
        ContentResolver cr = getContentResolver();
        MimeTypeMap mimeTypeMap = MimeTypeMap.getSingleton();
        return mimeTypeMap.getExtensionFromMimeType(cr.getType(uri));
    }

    private void uploadfile() {

        final String uid = currentUser.getUid();

        if (flag) {
            Log.d("first","true1");
            if (imguri != null) {
                Log.d("second","true2");
                final StorageReference fileReference = mStorageRef.child(currentUser.getUid()+ "." + getExtension(imguri));

                mUploadTAsk = fileReference.putFile(imguri)
                        .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                            @Override
                            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {

                                save.setEnabled(false);
                                progressDialog.dismiss();
                                Toast.makeText(getApplicationContext(), "Upload Successfull", Toast.LENGTH_SHORT).show();
                                /*Intent i = new Intent(getApplicationContext(),Drawer.class);
                                startActivity(i);
                                finish();*/
                                User_Up user_up = new User_Up(currentUser.getUid(),taskSnapshot.getDownloadUrl().toString());

                                mDatabaseRef.child("profile").setValue(user_up);

                                //Toast.makeText(getApplicationContext(), upload.getName() + " " + upload.getImguri(), Toast.LENGTH_SHORT).show();
                            }
                        })
                        .addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_SHORT).show();
                            }
                        })
                        .addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                            @Override
                            public void onProgress(UploadTask.TaskSnapshot taskSnapshot) {
                            }
                        });
            } else {
                Toast.makeText(getApplicationContext(), "No File Selected", Toast.LENGTH_SHORT).show();
            }
        }else {
            if(thumbnail != null){
                final StorageReference fileReference = mStorageRef.child(currentUser.getUid() + ".jpg");

                ByteArrayOutputStream stream = new ByteArrayOutputStream();
                thumbnail.compress(Bitmap.CompressFormat.JPEG, 100, stream);

                byte[] b = stream.toByteArray();

                mUploadTAsk = fileReference.putBytes(stream.toByteArray())
                        .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                            @Override
                            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {

                                save.setEnabled(false);
                                progressDialog.dismiss();
                                Toast.makeText(getApplicationContext(), "Upload Successfull", Toast.LENGTH_SHORT).show();
                                /*Intent i = new Intent(getApplicationContext(),Drawer.class);
                                startActivity(i);
                                finish();*/

                                User_Up user_up = new User_Up(currentUser.getUid(),taskSnapshot.getDownloadUrl().toString());
                                String uid = currentUser.getUid();
                                mDatabaseRef.child("profile").setValue(user_up);

                                //Toast.makeText(getApplicationContext(), upload.getName() + " " + upload.getImguri(), Toast.LENGTH_SHORT).show();
                            }
                        })
                        .addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_SHORT).show();
                            }
                        })
                        .addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                            @Override
                            public void onProgress(UploadTask.TaskSnapshot taskSnapshot) {
                            }
                        });
            } else {
                Toast.makeText(getApplicationContext(), "No File Selected", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void requestPermission() {

        ActivityCompat.requestPermissions(this,
                new String[]{Manifest.permission.CAMERA},
                MY_PERMISSIONS_REQUEST_CAMERA);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        switch (requestCode) {
            case MY_PERMISSIONS_REQUEST_CAMERA:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    //Toast.makeText(getApplicationContext(), "Permission Granted", Toast.LENGTH_SHORT).show();
                    takePhotoFromCamera();
                    // main logic
                } else {
                    Toast.makeText(getApplicationContext(), "Permission Denied", Toast.LENGTH_SHORT).show();
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                                != PackageManager.PERMISSION_GRANTED) {
                            showMessageOKCancel("You need to allow access permissions",
                                    new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialog, int which) {
                                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                                                requestPermission();
                                            }
                                        }
                                    });
                        }
                    }
                }
                break;
        }
    }

    private void showMessageOKCancel(String message, DialogInterface.OnClickListener okListener) {
        new android.app.AlertDialog.Builder(this)
                .setMessage(message)
                .setPositiveButton("OK", okListener)
                .setNegativeButton("Cancel", null)
                .create()
                .show();
    }

    @Override
    public void onBackPressed() {
        Intent i = new Intent(Profile.this,Drawer.class);
        startActivity(i);
        finish();
    }

    @Override
    public boolean onSupportNavigateUp() {
        Intent i = new Intent(Profile.this,Drawer.class);
        startActivity(i);
        finish();
        return true;
    }
}
