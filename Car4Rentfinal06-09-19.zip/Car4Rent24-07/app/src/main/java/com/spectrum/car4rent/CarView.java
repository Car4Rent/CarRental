package com.spectrum.car4rent;

class CarView {
    String regno,name,image,mileage,fuel,year,renthour,rentday,model,company,colour,seat,ac,gear,spare,userid,premium;
    long time;
    int popular;

    public CarView() {}

    public CarView(String regno, String image, String mileage, String fuel, String year, String renthour, String rentday, String model,
                   String company, String colour, String seat, String ac, String gear, String spare,String userid,Long time,int popular,String premium){
        this.regno=regno;
        //this.name=name;
        this.image=image;
        this.mileage=mileage;
        this.fuel=fuel;
        this.year=year;
        this.renthour=renthour;
        this.rentday=rentday;
        this.model=model;
        this.company=company;
        this.colour=colour;
        this.seat=seat;
        this.ac=ac;
        this.gear=gear;
        this.spare=spare;
        this.userid=userid;
        this.time=time;
        this.popular=popular;
        this.premium=premium;

    }

    public String getRegno() { return regno; }
    /*public String getName(){
        return name;
    }*/

    public String getImage(){
        return image;
    }
    public String getMileage(){
        return mileage;
    }
    public String getFuel(){
        return fuel;
    }
    public String getYear(){
        return year;
    }
    public String getRenthour(){
        return renthour;
    }
    public String getRentday(){
        return rentday;
    }
    public String getModel(){
        return model;
    }
    public String getCompany(){
        return company;
    }
    public String getColour(){
        return colour;
    }
    public String getSeat(){
        return seat;
    }
    public String getAc(){
        return ac;
    }
    public String getGear(){
        return gear;
    }
    public String getSpare(){
        return spare;
    }
    public String getUserid() {
        return userid;
    }
    public Long getTime() { return time; }
    public int getPopular() { return  popular; }
    public String getPremium() { return premium; }


    public void setRegno(String regno) { this.regno=regno; }
    /*public void setName(String name){
        this.name=name;
    }*/

    public void setImage(String image){
        this.image=image;
    }
    public void setMileage(String mileage){
        this.mileage=mileage;
    }
    public void setFuel(String fuel){
        this.fuel=fuel;
    }
    public void setYear(String year){
        this.year=year;
    }
    public void setRenthour(String renthour){
        this.renthour=renthour;
    }
    public void setRentday(String rentday){
        this.rentday=rentday;
    }
    public void setModel(String model){
        this.model=model;
    }
    public void setCompany(String company){
        this.company=company;
    }
    public void setColour(String color){
        this.colour=colour;
    }
    public void setSeat(String seat){
        this.seat=seat;
    }
    public void setAc(String ac){
        this.ac=ac;
    }
    public void setGear(String gear){
        this.gear=gear;
    }
    public void setSpare(String spare){
        this.spare=spare;
    }
    public void setUserid(String userid) {
        this.userid=userid;
    }
    public void setTime(Long time) { this.time=time; }
    public void setPopular(int popular) { this.popular=popular; }
    public void setPremium(String  premium) { this.premium=premium; }

}
