package com.spectrum.car4rent;

import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.view.Window;
import android.view.animation.Animation;
import android.widget.ImageView;
import android.widget.ProgressBar;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class Splash extends AppCompatActivity {

    long delay = 6000;
    ProgressBar progressBar;
    private int progressStatus = 0;
    private Handler handler = new Handler();
    Animation anim;
    ImageView img;
    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getSupportActionBar().hide();
        String bgcolor = "#1B1B6B";
        this.getWindow().setStatusBarColor(Color.parseColor(bgcolor));
        setContentView(R.layout.activity_splash);
        mAuth = FirebaseAuth.getInstance();
        /*
        SharedPreferences pref = getApplicationContext().getSharedPreferences("MyPref", MODE_PRIVATE);
        SharedPreferences.Editor editor = pref.edit();
        final Boolean login = pref.getBoolean("Flag",false);*/

        img = findViewById(R.id.t1);
        progressBar = findViewById(R.id.progressBar);

        progressBar.setProgressTintList(ColorStateList.valueOf(Color.WHITE));

        /*anim = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.move);
        img.startAnimation(anim);*/

        new Thread(new Runnable() {
            public void run() {
                while (progressStatus < 100) {
                    progressStatus += 5;
                    // Update the progress bar and display the
                    //current value in the text view
                    handler.post(new Runnable() {
                        public void run() {
                            progressBar.setProgress(progressStatus);
                        }
                    });
                    try {
                        // Sleep for 200 milliseconds.
                        Thread.sleep(200);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }

                finish();
                FirebaseUser currentUser = mAuth.getCurrentUser();
                if(currentUser!=null){
                    Intent i = new Intent(Splash.this,Drawer.class);
                    startActivity(i);
                }
                else {
                    Intent i = new Intent(Splash.this,Login.class);
                    startActivity(i);
                }
            }
        }).start();
    }

    @Override
    public void onBackPressed() { }
}


        /*Timer runSplash = new Timer();
        TimerTask showSplash = new TimerTask() {
            @Override
            public void run() {

                finish();
                Intent i = new Intent(getApplicationContext(),Login.class);
                startActivity(i);

            }
        };
        runSplash.schedule(showSplash,delay);
    }
}*/
