package com.spectrum.car4rent;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

import java.util.List;

public class ImageAdapter extends RecyclerView.Adapter<ImageAdapter.ImageViewHolder> {
    private Context mContext;
    private List<CarView> mUploads;

    public ImageAdapter(Context context, List<CarView> uploads) {
        mContext = context;
        mUploads = uploads;
    }

    @Override
    public ImageViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(mContext).inflate(R.layout.image_item, parent, false);
        return new ImageViewHolder(v);
    }

    @Override
    public void onBindViewHolder(ImageViewHolder holder, int position) {
        CarView uploadCurrent = mUploads.get(position);
        holder.textViewCompany.setText(uploadCurrent.getCompany());
        holder.textViewModel.setText(uploadCurrent.getModel());
        holder.textViewColor.setText(uploadCurrent.getColour());
        holder.textViewYear.setText(uploadCurrent.getYear());
        Picasso.get()
                .load(uploadCurrent.getImage())
                .placeholder(R.drawable.dummy_car)
                .fit()
                .into(holder.imageView);
    }

    @Override
    public int getItemCount() {
        return mUploads.size();
    }

    public class ImageViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener{
        public TextView textViewCompany,textViewModel,textViewColor,textViewYear;
        public ImageView imageView;

        public ImageViewHolder(View itemView) {
            super(itemView);

            textViewCompany = itemView.findViewById(R.id.car_company);
            textViewModel = itemView.findViewById(R.id.car_model);
            textViewColor = itemView.findViewById(R.id.car_color);
            textViewYear = itemView.findViewById(R.id.car_year);
            imageView = itemView.findViewById(R.id.image_view);

            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {
            int position = getLayoutPosition();
            CarView car = mUploads.get(position);
            //Toast.makeText(view.getContext(),car.getRegno(),Toast.LENGTH_LONG).show();

        }
    }
}