package com.spectrum.car4rent;

public class Register {
    private String id,name,phone,dob,email,password,img;
    public String getId()
    {
        return id;
    }
    public String getName()
    {
        return name;
    }
    public String getPhone()
    {
        return phone;
    }
    public String getDob()
    {
        return dob;
    }
    public String getEmail()
    {
        return email;
    }
    public String getPassword()
    {
        return password;
    }

    public String getImg() {
        return img;
    }

    public void setId(String id)
    {
        this.id=id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public void setDob(String dob) {
        this.dob = dob;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setImg(String img){
        this.img = img;
    }
}