package com.spectrum.car4rent;

import android.Manifest;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.icu.util.Calendar;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.StorageTask;
import com.google.firebase.storage.UploadTask;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

public class Add_car extends AppCompatActivity implements AdapterView.OnItemSelectedListener{

    ProgressDialog progressDialog;

    public static final int MY_PERMISSIONS_REQUEST_CAMERA = 100;

    private int GALLERY = 1, CAMERA = 2;
    public Uri imguri;
    Bitmap thumbnail;
    boolean flag;

    LinearLayout add_car_1,add_car_2,add_car_3,add_car_4;
    Button next1,next2,next3,prev1,prev2,prev3,submit;
    EditText year,refid,seat,mileage,reg_no,rent_day,rent_hour;
    Spinner ac,fuel,gear,spare,company,model,color,premium;
    String[] ac1 = {"Yes","No"},fuel1 = {"Petrol","Diesel"},gear1 = {"Manual","Automatic"},spare1 = {"Yes","No"};
    ImageView add,display_car;

    Pattern pattern = Pattern.compile("^[A-Z]{2}[0-9]{1,2}(?:[A-Z])?(?:[A-Z]*)?[0-9]{4}$");

    private FirebaseAuth firebaseAuth;
    private StorageReference mStorageRef;
    private DatabaseReference mDatabaseRef;
    private StorageTask mUploadTAsk;
    FirebaseUser currentUser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        String bgcolor = "#1B1B6B";
        ActionBar actionBar = getSupportActionBar();
        actionBar.setBackgroundDrawable(new ColorDrawable(Color.parseColor(bgcolor)));
        actionBar.setTitle("");
        actionBar.setDisplayHomeAsUpEnabled(true);
        this.getWindow().setStatusBarColor(Color.parseColor(bgcolor));
        setContentView( R.layout.activity_add_car );

        firebaseAuth = FirebaseAuth.getInstance();

        currentUser = firebaseAuth.getCurrentUser();

        mStorageRef = FirebaseStorage.getInstance().getReference("cars");
        mDatabaseRef = FirebaseDatabase.getInstance().getReference().child("cars");

        add_car_1 = findViewById(R.id.add_car_1);
        add_car_2 = findViewById(R.id.add_car_2);
        add_car_3 = findViewById(R.id.add_car_3);
        add_car_4 = findViewById(R.id.add_car_4);
        next1 = findViewById(R.id.next1);
        next2 = findViewById(R.id.next2);
        next3 = findViewById(R.id.next3);
        prev1 = findViewById(R.id.prev1);
        prev2 = findViewById(R.id.prev2);
        prev3 = findViewById(R.id.prev3);
        submit = findViewById(R.id.submit);

        reg_no = findViewById(R.id.reg_no);
        year = findViewById(R.id.year);
        company = findViewById(R.id.company);
        color = findViewById(R.id.color);
        model = findViewById(R.id.model);
        refid = findViewById(R.id.refid);
        seat = findViewById(R.id.seat);
        mileage = findViewById(R.id.mileage);
        ac = findViewById(R.id.ac);
        fuel = findViewById(R.id.fuel);
        gear = findViewById(R.id.gear);
        spare = findViewById(R.id.spare);
        rent_hour = findViewById(R.id.rent_hour);
        rent_day = findViewById(R.id.rent_day);
        add = findViewById(R.id.add);
        display_car = findViewById(R.id.display_car);
        premium = findViewById(R.id.premium);
        company.setOnItemSelectedListener(this);

        final ArrayAdapter list1 = new ArrayAdapter(this,android.R.layout.simple_spinner_item,ac1);
        list1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        ac.setAdapter(list1);

        ArrayAdapter list2 = new ArrayAdapter(this,android.R.layout.simple_spinner_item,fuel1);
        list2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        fuel.setAdapter(list2);

        ArrayAdapter list3 = new ArrayAdapter(this,android.R.layout.simple_spinner_item,gear1);
        list3.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        gear.setAdapter(list3);

        ArrayAdapter list4 = new ArrayAdapter(this,android.R.layout.simple_spinner_item,spare1);
        list4.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spare.setAdapter(list4);

        next1.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.N)
            @Override
            public void onClick(View view) {
                if (reg_no.getText().toString().equals("") || !reg_no.getText().toString().matches(String.valueOf(pattern))){
                    reg_no.setError("Please Enter a Valid Registration Number");
                }else if (year.getText().toString().equals("")){
                    year.setError("Please enter year");
                }else if (Integer.valueOf(year.getText().toString()) > Calendar.getInstance().get(Calendar.YEAR) || Integer.valueOf(year.getText().toString()) < 1950){
                    year.setError("Please enter a valid year");
                }
                /*else if (company.getText().toString().equals("")){
                    company.setError("Please Select the Company");
                }else if (model.getText().toString().equals("")){
                    model.setError("Please Select the Model");
                }else if (color.getText().toString().equals("")){
                    color.setError("Please select color of the car");
                }*/else {
                    add_car_1.setVisibility(View.GONE);
                    add_car_2.setVisibility(View.VISIBLE);
                }
                if (String.valueOf(model.getSelectedItem()).equals("Santro") ||
                        String.valueOf(model.getSelectedItem()).equals("Creta") ||
                        String.valueOf(model.getSelectedItem()).equals("Grand i10") ||
                        String.valueOf(model.getSelectedItem()).equals("Elite i20") ||
                        String.valueOf(model.getSelectedItem()).equals("Elantra") ||
                        String.valueOf(model.getSelectedItem()).equals("Bolt") ||
                        String.valueOf(model.getSelectedItem()).equals("Harrier") ||
                        String.valueOf(model.getSelectedItem()).equals("Nexon") ||
                        String.valueOf(model.getSelectedItem()).equals("Accord") ||
                        String.valueOf(model.getSelectedItem()).equals("Amaze") ||
                        String.valueOf(model.getSelectedItem()).equals("Brio") ||
                        String.valueOf(model.getSelectedItem()).equals("CR-V") ||
                        String.valueOf(model.getSelectedItem()).equals("Alto 800") ||
                        String.valueOf(model.getSelectedItem()).equals("Alto K10") ||
                        String.valueOf(model.getSelectedItem()).equals("Baleno") ||
                        String.valueOf(model.getSelectedItem()).equals("Baleno RS") ||
                        String.valueOf(model.getSelectedItem()).equals("Swift") ||
                        String.valueOf(model.getSelectedItem()).equals("E verito") ||
                        String.valueOf(model.getSelectedItem()).equals("KUV 100 NXT")){

                    seat.setText("5");
                }else if (String.valueOf(model.getSelectedItem()).equals("Hexa") ||
                        String.valueOf(model.getSelectedItem()).equals("BRV") ||
                        String.valueOf(model.getSelectedItem()).equals("Marazzo")){

                    seat.setText("7");
                }else if (String.valueOf(model.getSelectedItem()).equals("Scorpio") ||
                        String.valueOf(model.getSelectedItem()).equals("Bolero") ||
                        String.valueOf(model.getSelectedItem()).equals("Sumo")){

                    seat.setText("9");
                }
            }
        });

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showPictureDialog();
            }
        });

        next2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (imguri==null && thumbnail==null){
                    Toast.makeText(getApplicationContext(),"Please Insert a Picture of your car",Toast.LENGTH_SHORT).show();
                }else {
                    add_car_2.setVisibility(View.GONE);
                    add_car_3.setVisibility(View.VISIBLE);
                }
            }
        });

        prev1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                add_car_2.setVisibility(View.GONE);
                add_car_1.setVisibility(View.VISIBLE);
            }
        });

        next3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (seat.getText().toString().equals("")){
                    seat.setError("Enter no.of seats");
                }else if (Integer.valueOf(seat.getText().toString())>10 || Integer.valueOf(seat.getText().toString())<4) {
                    seat.setError("Enter a Valid Seat Number");
                }else if (mileage.getText().toString().equals("")){
                    mileage.setError("Enter Mileage");
                }else if (Integer.valueOf(mileage.getText().toString())>=50 || Integer.valueOf(mileage.getText().toString())<5) {
                    mileage.setError("Enter a Valid Mileage");
                }else {
                    add_car_3.setVisibility(View.GONE);
                    add_car_4.setVisibility(View.VISIBLE);
                }
            }
        });

        prev2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                add_car_3.setVisibility(View.GONE);
                add_car_2.setVisibility(View.VISIBLE);
            }
        });

        prev3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                add_car_4.setVisibility(View.GONE);
                add_car_3.setVisibility(View.VISIBLE);
            }
        });

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (Integer.valueOf(rent_day.getText().toString())<500){
                    rent_day.setError("Minimum Rate is Rs.400");
                }else if (Integer.valueOf(rent_hour.getText().toString())<70){
                    rent_hour.setError("Minimum Charge is Rs.80");
                }else if (mUploadTAsk != null && mUploadTAsk.isInProgress()){
                    Toast.makeText(getApplicationContext(),"Upload in Progress",Toast.LENGTH_SHORT).show();
                }else {
                    progressDialog = new ProgressDialog(Add_car.this);
                    progressDialog.setMessage("Uploading in Progress.....\nPlease Wait....");
                    progressDialog.show();
                    uploadfile();
                }
            }
        });

    }

    private void requestPermission() {

        ActivityCompat.requestPermissions(this,
                new String[]{Manifest.permission.CAMERA},
                MY_PERMISSIONS_REQUEST_CAMERA);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        switch (requestCode) {
            case MY_PERMISSIONS_REQUEST_CAMERA:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    //Toast.makeText(getApplicationContext(), "Permission Granted", Toast.LENGTH_SHORT).show();
                    takePhotoFromCamera();
                    // main logic
                } else {
                    Toast.makeText(getApplicationContext(), "Permission Denied", Toast.LENGTH_SHORT).show();
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                                != PackageManager.PERMISSION_GRANTED) {
                            showMessageOKCancel("You need to allow access permissions",
                                    new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialog, int which) {
                                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                                                requestPermission();
                                            }
                                        }
                                    });
                        }
                    }
                }
                break;
        }
    }

    private void showMessageOKCancel(String message, DialogInterface.OnClickListener okListener) {
        new AlertDialog.Builder(this)
                .setMessage(message)
                .setPositiveButton("OK", okListener)
                .setNegativeButton("Cancel", null)
                .create()
                .show();
    }

    private void showPictureDialog(){
        AlertDialog.Builder pictureDialog = new AlertDialog.Builder(this);
        pictureDialog.setTitle("");
        String[] pictureDialogItems = {
                "Choose photo from Files",
                "Take a photo From Camera","Cancel" };
        pictureDialog.setItems(pictureDialogItems,
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        switch (which) {
                            case 0:
                                Filechooser();
                                break;
                            case 1:
                                if (ContextCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                                    requestPermission();
                                }else {
                                    takePhotoFromCamera();
                                }
                                break;
                            case 2:
                                dialog.dismiss();
                        }
                    }
                });
        pictureDialog.show();
    }

    private String getExtension(Uri uri){
        ContentResolver cr = getContentResolver();
        MimeTypeMap mimeTypeMap = MimeTypeMap.getSingleton();
        return mimeTypeMap.getExtensionFromMimeType(cr.getType(uri));
    }

    public static String getExt(Bitmap image) {
        Bitmap immagex = image;
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        immagex.compress(Bitmap.CompressFormat.PNG, 100, baos);
        byte[] b = baos.toByteArray();
        String imageEncoded = Base64.encodeToString(b, Base64.DEFAULT);
        return imageEncoded;
    }

    public Uri getImageUri(Context inContext, Bitmap inImage) {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        inImage.compress(Bitmap.CompressFormat.JPEG, 100, bytes);
        String path = MediaStore.Images.Media.insertImage(inContext.getContentResolver(), inImage, "Title", null);
        return Uri.parse(path);
    }

    private void Filechooser() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(intent.ACTION_GET_CONTENT);
        startActivityForResult(intent,GALLERY);
    }

    private void takePhotoFromCamera() {
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        startActivityForResult(intent, CAMERA);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == this.RESULT_CANCELED) {
            return;
        }
        if (requestCode == GALLERY) {
            if (data != null) {
                imguri = data.getData();
                display_car.setImageURI(imguri);
                flag = true;
            }
        } else if (requestCode == CAMERA) {
            thumbnail = (Bitmap) data.getExtras().get("data");
            display_car.setImageBitmap(thumbnail);
            flag=false;
        }
    }

    private void uploadfile() {

        if (flag) {
            Log.d("first","true1");
            if (imguri != null) {
                Log.d("second","true2");
                final StorageReference fileReference = mStorageRef.child(System.currentTimeMillis() + "." + getExtension(imguri));

                mUploadTAsk = fileReference.putFile(imguri)
                        .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                            @Override
                            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {

                                progressDialog.dismiss();
                                Toast.makeText(getApplicationContext(), "Upload Successfull", Toast.LENGTH_SHORT).show();
                                Intent i = new Intent(getApplicationContext(),Drawer.class);
                                startActivity(i);
                                finish();
                                CarView upload = new CarView(reg_no.getText().toString().trim(), taskSnapshot.getDownloadUrl().toString(),
                                        mileage.getText().toString().trim(),String.valueOf(fuel.getSelectedItem()),
                                        year.getText().toString().trim(),rent_hour.getText().toString().trim(),
                                        rent_day.getText().toString().trim(),String.valueOf(model.getSelectedItem()),
                                        String.valueOf(company.getSelectedItem()), String.valueOf(color.getSelectedItem()),
                                        seat.getText().toString().trim(),String.valueOf(ac.getSelectedItem()),
                                        String.valueOf(gear.getSelectedItem()),String.valueOf(spare.getSelectedItem()),
                                        currentUser.getUid(),System.currentTimeMillis(),0,
                                        String.valueOf(premium.getSelectedItem()));
                                mDatabaseRef.child(upload.getRegno()).setValue(upload);

                                //Toast.makeText(getApplicationContext(), upload.getName() + " " + upload.getImguri(), Toast.LENGTH_SHORT).show();
                            }
                        })
                        .addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_SHORT).show();
                            }
                        })
                        .addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                            @Override
                            public void onProgress(UploadTask.TaskSnapshot taskSnapshot) {
                            }
                        });
            } else {
                Toast.makeText(getApplicationContext(), "No File Selected", Toast.LENGTH_SHORT).show();
            }
        }else {
            if(thumbnail != null){
                final StorageReference fileReference = mStorageRef.child(System.currentTimeMillis() + ".jpg");

                ByteArrayOutputStream stream = new ByteArrayOutputStream();
                thumbnail.compress(Bitmap.CompressFormat.JPEG, 100, stream);

                byte[] b = stream.toByteArray();

                mUploadTAsk = fileReference.putBytes(stream.toByteArray())
                        .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                            @Override
                            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                                progressDialog.dismiss();
                                Toast.makeText(getApplicationContext(), "Upload Successfull", Toast.LENGTH_SHORT).show();
                                Intent i = new Intent(getApplicationContext(),Drawer.class);
                                startActivity(i);
                                finish();
                                CarView upload = new CarView(reg_no.getText().toString().trim(),
                                        taskSnapshot.getDownloadUrl().toString(),
                                        mileage.getText().toString().trim(),
                                        String.valueOf(fuel.getSelectedItem()),
                                        year.getText().toString().trim(),
                                        rent_hour.getText().toString().trim(),
                                        rent_day.getText().toString().trim(),
                                        String.valueOf(model.getSelectedItem()),
                                        String.valueOf(company.getSelectedItem()),
                                        String.valueOf(color.getSelectedItem()),
                                        seat.getText().toString().trim(),
                                        String.valueOf(ac.getSelectedItem()),
                                        String.valueOf(gear.getSelectedItem()),
                                        String.valueOf(spare.getSelectedItem()),
                                        currentUser.getUid(),System.currentTimeMillis(),0,
                                        String.valueOf(premium.getSelectedItem()));
                                String uploadId = mDatabaseRef.push().getKey();
                                mDatabaseRef.child(uploadId).setValue(upload);

                                //Toast.makeText(getApplicationContext(), upload.getName() + " " + upload.getImguri(), Toast.LENGTH_SHORT).show();
                            }
                        })
                        .addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_SHORT).show();
                            }
                        })
                        .addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                            @Override
                            public void onProgress(UploadTask.TaskSnapshot taskSnapshot) {
                            }
                        });
            } else {
                Toast.makeText(getApplicationContext(), "No File Selected", Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    public void onItemSelected(AdapterView<?> arg0, View arg1, int arg2,
                               long arg3) {

        String sp1= String.valueOf(company.getSelectedItem());

        if(sp1.contentEquals("Hyundai")) {
            List<String> list = new ArrayList<String>();
            list.add("Creta");
            list.add("Elantra");
            list.add("Elite i20");
            list.add("Grand i10");
            list.add("Santro");
            ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this,
                    android.R.layout.simple_spinner_item, list);
            dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            dataAdapter.notifyDataSetChanged();
            model.setAdapter(dataAdapter);
        }
        if(sp1.contentEquals("Tata")) {
            List<String> list = new ArrayList<String>();
            list.add("Bolt");
            list.add("Harrier");
            list.add("Hexa");
            list.add("Sumo");
            list.add("Nexon");
            ArrayAdapter<String> dataAdapter2 = new ArrayAdapter<String>(this,
                    android.R.layout.simple_spinner_item, list);
            dataAdapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            dataAdapter2.notifyDataSetChanged();
            model.setAdapter(dataAdapter2);
        }
        if(sp1.contentEquals("Honda")) {
            List<String> list = new ArrayList<String>();
            list.add("Accord");
            list.add("Amaze");
            list.add("BRV");
            list.add("Brio");
            list.add("CR-V");
            ArrayAdapter<String> dataAdapter2 = new ArrayAdapter<String>(this,
                    android.R.layout.simple_spinner_item, list);
            dataAdapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            dataAdapter2.notifyDataSetChanged();
            model.setAdapter(dataAdapter2);
        }
        if(sp1.contentEquals("Maruti")) {
            List<String> list = new ArrayList<String>();
            list.add("Alto 800");
            list.add("Alto K10");
            list.add("Baleno");
            list.add("Baleno RS");
            list.add("Swift");
            ArrayAdapter<String> dataAdapter2 = new ArrayAdapter<String>(this,
                    android.R.layout.simple_spinner_item, list);
            dataAdapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            dataAdapter2.notifyDataSetChanged();
            model.setAdapter(dataAdapter2);
        }
        if(sp1.contentEquals("Mahindra")) {
            List<String> list = new ArrayList<String>();
            list.add("Bolero");
            list.add("E verito");
            list.add("KUV 100 NXT");
            list.add("Marazzo");
            list.add("Scorpio");
            ArrayAdapter<String> dataAdapter2 = new ArrayAdapter<String>(this,
                    android.R.layout.simple_spinner_item, list);
            dataAdapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            dataAdapter2.notifyDataSetChanged();
            model.setAdapter(dataAdapter2);
        }


    }
    @Override
    public void onNothingSelected(AdapterView<?> arg0) { }

    @Override
    public void onBackPressed() { }

    @Override
    public boolean onSupportNavigateUp() {
        super.onBackPressed();
        return true;
    }
}