package com.spectrum.car4rent;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.ContextMenu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class Car_Details extends AppCompatActivity {

    /*private RecyclerView mRecyclerView;
    private ImageAdapter mImageAdapter;
    private BookedAdapter mBookedAdapter;*/
    private TextView nothing;

    private ProgressBar progressCircle;

    private DatabaseReference mDatabaseRef;
    /*private List<CarView> mUploads;
    private List<Book> mBook;*/
    FirebaseAuth mAuth;
    FirebaseUser currentUser;
    private RecyclerView rvviewcars;
    private LinearLayoutManager linearLayoutManager;

    private MyAdapter adapter;
    private BookedAdapter adapter1;
    private List<CarView> listData;
    private List<Book> listData1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        String bgcolor = "#1B1B6B";
        ActionBar actionBar = getSupportActionBar();
        actionBar.setBackgroundDrawable(new ColorDrawable(Color.parseColor(bgcolor)));
        actionBar.setTitle("");
        actionBar.setDisplayHomeAsUpEnabled(true);
        this.getWindow().setStatusBarColor(Color.parseColor(bgcolor));
        setContentView(R.layout.activity_car__details);

        mAuth = FirebaseAuth.getInstance();
        currentUser = mAuth.getCurrentUser();

        Intent j = getIntent();
        boolean check = j.getBooleanExtra("Value",false);

/*
            mRecyclerView = findViewById(R.id.recycler_view);
            mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
            mRecyclerView.setHasFixedSize(true);
*/
            rvviewcars = findViewById(R.id.recycler_view);
            linearLayoutManager = new LinearLayoutManager(this);
            listData=new ArrayList();

            findViewById(R.id.progress_circle).setVisibility(View.VISIBLE);
            nothing = findViewById(R.id.nothing);
            if(!check){
                linearLayoutManager = new LinearLayoutManager(this);
                rvviewcars.setHasFixedSize(true);
                rvviewcars.setLayoutManager(linearLayoutManager);
                listData=new ArrayList();
                Log.e("gskdjgs", String.valueOf(listData.isEmpty()));
                DatabaseReference nj= FirebaseDatabase.getInstance().getReference("cars");
                nj.addListenerForSingleValueEvent(new ValueEventListener() {
                    CarView l;
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        if (dataSnapshot.exists()) {
                            for (DataSnapshot npsnapshot : dataSnapshot.getChildren()) {
                                l = npsnapshot.getValue(CarView.class);
                                if(l.getUserid().equals(currentUser.getUid())) {
                                    listData.add(l);
                                }
                            }
                            Log.e("gskdjgs", String.valueOf(listData.isEmpty()));
                            findViewById(R.id.progress_circle).setVisibility(View.GONE);
                            adapter = new MyAdapter(getApplicationContext(),listData,0);
                            rvviewcars.setAdapter(adapter);


                        }
                        else{
                            nothing.setVisibility(View.VISIBLE);
                            findViewById(R.id.progress_circle).setVisibility(View.GONE);
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });

            }else if(check){
                linearLayoutManager = new LinearLayoutManager(this);
                rvviewcars.setHasFixedSize(true);
                rvviewcars.setLayoutManager(linearLayoutManager);
                listData=new ArrayList();
                Log.e("gskdjgs", String.valueOf(listData.isEmpty()));
                DatabaseReference nj= FirebaseDatabase.getInstance().getReference("book");
                nj.addListenerForSingleValueEvent(new ValueEventListener() {
                    Book l;
                    CarView l1;
                    @Override
                    public void onDataChange(final DataSnapshot dataSnapshot) {
                        if (dataSnapshot.exists()) {
                            for (DataSnapshot psnapshot : dataSnapshot.getChildren()) {
                                DatabaseReference dg=psnapshot.getRef();
                                dg.addListenerForSingleValueEvent(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(DataSnapshot dataSnapshot1) {
                                        if(dataSnapshot1.exists()){
                                            for(DataSnapshot npsnapshot:dataSnapshot1.getChildren()) {
                                                l = npsnapshot.getValue(Book.class);
                                                if (l.getBooker().equals(currentUser.getUid())) {
                                                    Log.e("gsk123",l.getKey());
                                                    DatabaseReference dcar=FirebaseDatabase.getInstance().getReference("cars/"+l.getKey());
                                                    dcar.addListenerForSingleValueEvent(new ValueEventListener() {
                                                        @Override
                                                        public void onDataChange(DataSnapshot dataSnapshot2) {
                                                            if(dataSnapshot2.exists()) {
                                                                l1 = dataSnapshot2.getValue(CarView.class);
                                                                Log.e("gsk123",l1.getRegno());
                                                                Log.e("gsk123",dataSnapshot2.getKey());

                                                                listData.add(l1);
                                                            }
                                                            else {
                                                                nothing.setVisibility(View.VISIBLE);
                                                                findViewById(R.id.progress_circle).setVisibility(View.GONE);
                                                            }
                                                        }

                                                        @Override
                                                        public void onCancelled(DatabaseError databaseError) {

                                                        }
                                                    });
                                                }
                                            }
                                        }
                                    }

                                    @Override
                                    public void onCancelled(DatabaseError databaseError) {

                                    }
                                });

                            }
                            Log.e("gskdjgs", String.valueOf(listData.isEmpty()));
                            if(!listData.isEmpty()){
                                nothing.setVisibility(View.VISIBLE);
                                findViewById(R.id.progress_circle).setVisibility(View.GONE);
                            }else {
                                adapter = new MyAdapter(getApplicationContext(), listData, 1);
                                rvviewcars.setAdapter(adapter);
                                findViewById(R.id.progress_circle).setVisibility(View.GONE);
                            }

                        }
                        else{
                            nothing.setVisibility(View.VISIBLE);
                            findViewById(R.id.progress_circle).setVisibility(View.GONE);
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });


            }

      /*      mUploads = new ArrayList<>();
            mBook = new ArrayList<>();
*/
            /*if (check==true) {

                mDatabaseRef = FirebaseDatabase.getInstance().getReference("cars");

                progressCircle = findViewById(R.id.progress_circle);

                mDatabaseRef.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        for (DataSnapshot postSnapshot : dataSnapshot.getChildren()){
                            CarView upload = postSnapshot.getValue(CarView.class);
                            if (upload.getUserid().equals(currentUser.getUid())) {
                                mUploads.add(upload);
                            }

                        }
                        if (mUploads.isEmpty()) {
                            nothing.setVisibility(View.VISIBLE);
                            //Toast.makeText(getApplicationContext(),"Nothing to Show",Toast.LENGTH_LONG).show();
                        }else {

                            mImageAdapter = new ImageAdapter(Car_Details.this, mUploads);

                            mRecyclerView.setAdapter(mImageAdapter);

                        }

                        progressCircle.setVisibility(View.INVISIBLE);
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                        Toast.makeText(getApplicationContext(),databaseError.getMessage(),Toast.LENGTH_SHORT).show();
                        progressCircle.setVisibility(View.INVISIBLE);
                    }
                });
            }else {
                mDatabaseRef = FirebaseDatabase.getInstance().getReference("book");

                progressCircle = findViewById(R.id.progress_circle);

                mDatabaseRef.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                            DatabaseReference ref = mDatabaseRef.child(String.valueOf(dataSnapshot));
                            ref.addListenerForSingleValueEvent(new ValueEventListener() {
                                @Override
                                public void onDataChange(DataSnapshot dataSnapshot) {
                                    for (DataSnapshot postSnapshot : dataSnapshot.getChildren()) {
                                        Book upload = postSnapshot.getValue(Book.class);

                                            mBook.add(upload);

                                    }
                                }

                                @Override
                                public void onCancelled(DatabaseError databaseError) {

                                }
                            });


                        if (mBook.isEmpty()) {
                            nothing.setVisibility(View.VISIBLE);
                            //Toast.makeText(getApplicationContext(),"Nothing to Show",Toast.LENGTH_LONG).show();
                        }else {

                            mBookedAdapter = new BookedAdapter(Car_Details.this,mBook);

                            mRecyclerView.setAdapter(mBookedAdapter);

                        }

                        progressCircle.setVisibility(View.INVISIBLE);
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                        Toast.makeText(getApplicationContext(),databaseError.getMessage(),Toast.LENGTH_SHORT).show();
                        progressCircle.setVisibility(View.INVISIBLE);
                    }
                });
            }
*/

    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo)
    {
        super.onCreateContextMenu(menu, v, menuInfo);
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.context_menu, menu);
        menu.setHeaderTitle("Select The Action");
    }
    @Override
    public boolean onContextItemSelected(MenuItem item){
        if(item.getItemId()==R.id.call){
            Toast.makeText(getApplicationContext(),"calling code",Toast.LENGTH_LONG).show();
        }
        else if(item.getItemId()==R.id.sms){
            Toast.makeText(getApplicationContext(),"sending sms code",Toast.LENGTH_LONG).show();
        }else{
            return false;
        }
        return true;
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}
