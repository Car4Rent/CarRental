package com.spectrum.car4rent;

import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.TextView;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.yahoo.mobile.client.android.util.rangeseekbar.RangeSeekBar;

import java.util.ArrayList;
import java.util.Arrays;

public class Filter extends AppCompatActivity {

    GridView gvfuel,gvcolor;

    Button milege10,milege1015,milege15,auto,mannual,addseat,minusseat;
    Boolean flagmilege10,flagmilege15,flagmilege1015,flaggearauto,flaggearmanual,flagac;
    static Boolean[] flagbrand;
    Boolean[] flagfuel;
    Boolean[] flagcolor;
    TextView seatno;
    EditText minprice,maxprice;
    RangeSeekBar rangeSeekbar ;
    int preMin=-1;
    int preMax=-1;
    int count;
    RecyclerView rvbrands;
    private GridLayoutManager gridLayoutManager;

    private String[] fuel;
    private DatabaseReference mDatabase;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        String bgcolor = "#1B1B6B";
        ActionBar actionBar = getSupportActionBar();
        actionBar.setBackgroundDrawable(new ColorDrawable(Color.parseColor(bgcolor)));
        this.getWindow().setStatusBarColor(Color.parseColor(bgcolor));

        setContentView(R.layout.activity_filter);
        count=0;

        flaggearauto = false;
        flaggearmanual = false;
        flagmilege10 = false;
        flagmilege15 = false;
        flagmilege1015 = false;
        flagac=false;

        ArrayList brandNames = new ArrayList<>(Arrays.asList("Maruti","Hyundai", "Honda", "Tata", "Mahindra", "Renault", "Ford", "Nissan", "Datsun", "Toyota", "MG", "Volkswagen"));
        ArrayList brandImages = new ArrayList<>(Arrays.asList(R.drawable.maruti,R.drawable.hyundai,R.drawable.honda,R.drawable.tata,R.drawable.mahindra,R.drawable.renault,R.drawable.ford,R.drawable.nissan,R.drawable.datsun ,R.drawable.toyota,R.drawable.mg,R.drawable.volkswagen));
        flagbrand=new Boolean[brandNames.size()];

        fuel= new String[]{"Petrol", "Diesel"/*,"CNG","Electric"*/};

        flagfuel= new Boolean[]{false, false/*, false, false*/};
        mDatabase = FirebaseDatabase.getInstance().getReference();

        rangeSeekbar = findViewById(R.id.rangeSeekbar);
        maxprice = findViewById(R.id.fltr_et_maxPrice);
        minprice = findViewById(R.id.fltr_et_minPrice);
        milege1015 = findViewById(R.id.fltr_btn_kmpl_10to15);
        milege10 = findViewById(R.id.fltr_btn_kmpl_under10);
        milege15 = findViewById(R.id.fltr_btn_kmpl_above15);
        auto = findViewById(R.id.fltr_btn_auto);
        mannual = findViewById(R.id.fltr_btn_manual);
        addseat = findViewById(R.id.fltr_btn_plus);
        minusseat = findViewById(R.id.fltr_btn_minus);
        seatno = findViewById(R.id.fltr_tv_seat);

        rangeSeekbar.setNotifyWhileDragging(true);

        rangeSeekbar.setOnRangeSeekBarChangeListener(new RangeSeekBar.OnRangeSeekBarChangeListener<Integer>() {
            @Override
            public void onRangeSeekBarValuesChanged(RangeSeekBar<?> bar, Integer minValue, Integer maxValue) {

                int diff = maxValue - minValue;
                if (diff <= 500) {
                    if (minValue != preMin) {
                        rangeSeekbar.setSelectedMinValue(preMin);
                    } else if (maxValue != preMax) {
                        rangeSeekbar.setSelectedMaxValue(preMax);
                    }

                } else {
                    preMin = minValue;
                    preMax = maxValue;
                }
                minprice.setText(String.valueOf(preMin));
                maxprice.setText(String.valueOf(preMax));
            }
        });


        milege10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (flagmilege10) {
                    flagmilege10 = false;
                    milege10.setBackgroundResource(R.drawable.filter_rect_btn);
                } else {
                    flagmilege10 = true;
                    milege10.setBackgroundResource(R.drawable.filter_rect_btn_on);
                }
            }
        });
        milege15.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (flagmilege15) {
                    flagmilege15 = false;
                    milege15.setBackgroundResource(R.drawable.filter_rect_btn);
                } else {
                    flagmilege15 = true;
                    milege15.setBackgroundResource(R.drawable.filter_rect_btn_on);
                }
            }
        });
        milege1015.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (flagmilege1015) {
                    flagmilege1015 = false;
                    milege1015.setBackgroundResource(R.drawable.filter_rect_btn);
                } else {
                    flagmilege1015 = true;
                    milege1015.setBackgroundResource(R.drawable.filter_rect_btn_on);
                }
            }
        });
        auto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (flaggearauto) {
                    flaggearauto = false;
                    auto.setBackgroundResource(R.drawable.filter_rect_btn);
                } else {
                    flaggearauto = true;
                    auto.setBackgroundResource(R.drawable.filter_rect_btn_on);
                }
            }
        });
        mannual.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (flaggearmanual) {
                    flaggearmanual = false;
                    mannual.setBackgroundResource(R.drawable.filter_rect_btn);
                } else {
                    flaggearmanual = true;
                    mannual.setBackgroundResource(R.drawable.filter_rect_btn_on);
                }
            }
        });
        addseat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int no = Integer.parseInt(seatno.getText().toString());
                if (no < 10) {
                    no++;
                    seatno.setText(String.valueOf(no));
                }
                if (no == 10) {
                    addseat.setEnabled(false);
                }
                if (no == 3) {
                    minusseat.setEnabled(true);
                }

            }
        });
        minusseat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int no = Integer.parseInt(seatno.getText().toString());
                if (no > 2) {
                    no--;
                    seatno.setText(String.valueOf(no));
                }
                if (no == 2) {
                    minusseat.setEnabled(false);
                }
                if (no == 9) {
                    addseat.setEnabled(true);
                }

            }
        });

        //popular brands
        rvbrands = findViewById(R.id.fltr_rv_Brands);
        gridLayoutManager = new GridLayoutManager(this,4);
        rvbrands.setLayoutManager(gridLayoutManager);
        rvbrands.setHasFixedSize(true);
        Popular_Brands customAdapter = new Popular_Brands(Filter.this,brandNames,brandImages);
        rvbrands.setAdapter(customAdapter);

        //fuel
        gvfuel = findViewById(R.id.fltr_gv_fuel);

        //fuelList = new ArrayList<>();
        ArrayAdapter adapter1 = new ArrayAdapter<String>(this, R.layout.gvtextview, R.id.textview1,fuel);
        //this method will fetch and parse the data
        gvfuel.setAdapter(adapter1);
        gvfuel.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                if(flagfuel[i]){
                    flagfuel[i]=false;
                    view.setBackgroundResource(R.drawable.filter_rect_btn);
                }else{
                    flagfuel[i]=true;
                    view.setBackgroundResource(R.drawable.filter_rect_btn_on);
                }
            }
        });
        Button filter=findViewById(R.id.fltr_submit);
        filter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String maxpriceValue=maxprice.getText().toString();
                String minpriceValue=minprice.getText().toString();
                if(findViewById(R.id.fltr_switch_ac).isSelected()){
                    flagac=true;
                }else {
                    flagac = false;
                }
                //flagbrand[];
//                flaggearmanual;
//                flaggearauto;
//                flagmilege10;
//                flagfuel;
//                flagmilege15;
//                flagmilege1015;
//                flagac;

            }
        });
    }

}


