package com.spectrum.car4rent;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.PopupMenu;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

public class Drawer extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {

    SharedPreferences pref;
    SharedPreferences.Editor editor;
    private FirebaseAuth firebaseAuth;
    FirebaseUser currentUser;
    TextView textView;
    Button  filter;

    private RecyclerView rvviewcars;
    private LinearLayoutManager linearLayoutManager;

    private MyAdapter adapter;
    private List<CarView> listData;

    private DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        String bgcolor = "#1B1B6B";
        this.getWindow().setStatusBarColor(Color.parseColor(bgcolor));

        setContentView(R.layout.activity_drawer);
        Toolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setBackgroundColor(Color.parseColor(bgcolor));
        setSupportActionBar(toolbar);
        currentUser = FirebaseAuth.getInstance().getCurrentUser();

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();
        navigationView.setNavigationItemSelectedListener(this);

        firebaseAuth= FirebaseAuth.getInstance();

        pref = getApplicationContext().getSharedPreferences("MyPref", MODE_PRIVATE);
        editor = pref.edit();

        View view = navigationView.getHeaderView(0);
        final ImageView pro_pic = view.findViewById(R.id.profile_pic);

        pro_pic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FirebaseUser currentUser = firebaseAuth.getCurrentUser();
                Intent i = new Intent(getApplicationContext(),Profile.class);
                startActivity(i);
                finish();
            }
        });

        DatabaseReference dref = FirebaseDatabase.getInstance().getReference("User/"+currentUser.getUid()+"/profile/img");

        dref.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                if (snapshot.exists()){
                    Picasso.get().
                        load(snapshot.getValue().toString())
                        .centerCrop()
                        .fit()
                        .into(pro_pic);
                }
            }
            @Override
            public void onCancelled(DatabaseError databaseError) {
            }
        });

        DatabaseReference dref2 = FirebaseDatabase.getInstance().getReference("User/"+currentUser.getUid());
        dref2.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                //Toast.makeText(getApplicationContext(),snapshot.getValue().toString(),Toast.LENGTH_LONG).show();
                Register reg = snapshot.getValue(Register.class);
                textView = findViewById(R.id.textView);
                textView.setText(reg.getName());

            }
            @Override
            public void onCancelled(DatabaseError databaseError) {
            }
        });

        Log.d("Home", "on start");
        databaseReference = FirebaseDatabase.getInstance().getReference();

        //popular brands
        rvviewcars = findViewById(R.id.home_rv_viewcars);
        rvviewcars.setHasFixedSize(true);
        linearLayoutManager = new LinearLayoutManager(this);
        listData=new ArrayList();
        rvviewcars.setLayoutManager(linearLayoutManager);
        sortedrecycle(0);
        final FloatingActionButton sort = findViewById(R.id.fab);
        sort.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Creating the instance of PopupMenu
                PopupMenu popup = new PopupMenu(Drawer.this,sort);
                //Inflating the Popup using xml file
                popup.getMenuInflater().inflate(R.menu.sorting_menu, popup.getMenu());

                //registering popup with OnMenuItemClickListener
                popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    public boolean onMenuItemClick(MenuItem item) {

                        switch (item.getItemId()){
                            case R.id.sortmenu_Latest:{
                                sortedrecycle(1);break;
                            }
                            case R.id.sortmenu_Mileage_H_L:{
                                sortedrecycle(2);break;
                            }
                            case R.id.sortmenu_Mileage_L_H:{
                                sortedrecycle(3);break;
                            }
                            case R.id.sortmenu_Popularity:{
                                sortedrecycle(4);break;
                            }
                            case R.id.sortmenu_Price_H_L:{
                                sortedrecycle(5);break;
                            }
                            case R.id.sortmenu_Price_L_H:{
                                sortedrecycle(6);break;
                            }
                            default:
                                sortedrecycle(0);
                        }

                            /*Query myTopPostsQuery = databaseReference.child(Cars_table).orderByChild(price);
                        myTopPostsQuery.addChildEventListener(new ChildEventListener() {

                        });*/
                        return true;
                    }
                });

                popup.show();//showing popup menu
            }

        });



/*        sort= findViewById(R.id.hp_btn_sort);
        sort.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                //Creating the instance of PopupMenu
                PopupMenu popup = new PopupMenu(Drawer.this, sort);
                //Inflating the Popup using xml file
                popup.getMenuInflater().inflate(R.menu.sorting_menu, popup.getMenu());

                //registering popup with OnMenuItemClickListener
                popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    public boolean onMenuItemClick(MenuItem item) {

                        switch (item.getItemId()){
                            case R.id.sortmenu_Latest:{
                                sortedrecycle(1);break;
                            }
                            case R.id.sortmenu_Mileage_H_L:{
                                sortedrecycle(2);break;
                            }
                            case R.id.sortmenu_Mileage_L_H:{
                                sortedrecycle(3);break;
                            }
                            case R.id.sortmenu_Popularity:{
                                sortedrecycle(4);break;
                            }
                            case R.id.sortmenu_Price_H_L:{
                                sortedrecycle(5);break;
                            }
                            case R.id.sortmenu_Price_L_H:{
                                sortedrecycle(6);break;
                            }
                            default:
                                sortedrecycle(0);
                        }

                            *//*Query myTopPostsQuery = databaseReference.child(Cars_table).orderByChild(price);
                        myTopPostsQuery.addChildEventListener(new ChildEventListener() {

                        });*//*
                        return true;
                    }
                });

                popup.show();//showing popup menu
            }
        });*/
/*        filter = (Button) findViewById(R.id.home_btn_filter);


        filter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(Drawer.this, Filter.class);
                startActivity(i);

            }
        });
*/



    }

    private void sortedrecycle(int i) {
        DatabaseReference nm = FirebaseDatabase.getInstance().getReference("cars");
        Query nj = nm;
        linearLayoutManager = new LinearLayoutManager(this);
        switch (i){
            case 1:{
                linearLayoutManager.setReverseLayout(true);
                linearLayoutManager.setStackFromEnd(true);
                nj=nm.orderByChild("time");
                break;
            }
            case 2:{
                linearLayoutManager.setReverseLayout(true);
                linearLayoutManager.setStackFromEnd(true);
                nj=nm.orderByChild("mileage");break;
            }
            case 3:{

                nj=nm.orderByChild("mileage");break;
            }
            case 4:{
                linearLayoutManager.setReverseLayout(true);
                linearLayoutManager.setStackFromEnd(true);
                nj=nm.orderByChild("popularity");break;
            }
            case 5:{
                linearLayoutManager.setReverseLayout(true);
                linearLayoutManager.setStackFromEnd(true);
                nj=nm.orderByChild("renthour");
                break;
            }
            case 6:{
                nj=nm.orderByChild("renthour");
                break;
            }
            default:{
                nj=nj;
            }
        }
            rvviewcars.setHasFixedSize(true);
            rvviewcars.setLayoutManager(linearLayoutManager);
            listData=new ArrayList();
            nj.addListenerForSingleValueEvent(new ValueEventListener() {
                CarView l;
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {
                    if (dataSnapshot.exists()) {
                        for (DataSnapshot npsnapshot : dataSnapshot.getChildren()) {
                            l = npsnapshot.getValue(CarView.class);
                            if(l.getPremium().equals("No"))
                                    listData.add(l);
                        }
                        findViewById(R.id.progress_bar_home).setVisibility(View.GONE);
                        adapter = new MyAdapter(getApplicationContext(),listData,2);
                        rvviewcars.setAdapter(adapter);


                    }
                    else{
                        findViewById(R.id.textVi).setVisibility(View.VISIBLE);
                        findViewById(R.id.progress_bar_home).setVisibility(View.GONE);
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });




/*        filter = (Button) findViewById(R.id.home_btn_filter);


        filter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(Drawer.this, Filter.class);
                startActivity(i);

            }
        });
*/



    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.drawer, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.add_car) {
            Intent i = new Intent(getApplicationContext(),Add_car.class);
            startActivity(i);
        } else if (id == R.id.view_car) {
            Intent i = new Intent(getApplicationContext(),Car_Details.class);
            i.putExtra("Value",false);
            startActivity(i);
        } else if (id == R.id.booked_cars) {
            Intent i = new Intent(getApplicationContext(),Car_Details.class);
            i.putExtra("Value",true);
            startActivity(i);
        } else if (id == R.id.premium_cars) {
            Intent i = new Intent(getApplicationContext(),PremiumCars.class);
            startActivity(i);
        }
        else if (id == R.id.nav_logout){
            FirebaseAuth.getInstance().signOut();
            Intent i = new Intent(getApplicationContext(),Login.class);
            startActivity(i);
            finish();
        }else if (id == R.id.nav_share) {

        } else if (id == R.id.nav_send) {

        } else if (id == R.id.about){
            Intent i = new Intent(getApplicationContext(),About.class);
            startActivity(i);
        }

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
}
