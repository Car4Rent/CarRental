package com.spectrum.car4rent;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.basgeekball.awesomevalidation.AwesomeValidation;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.SignInButton;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.GoogleAuthProvider;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class Login extends AppCompatActivity {
    private static final String TAG = "Login";
    private static final int RC_SIGN_IN = 101;
    EditText email, password;
    Button login;
    TextView register;
    TextView forgottxt;
    String mail,pass;
    final Register register1=new Register();
    DatabaseReference db;

    private AwesomeValidation awesomeValidation;
    private FirebaseAuth mAuth;
    private GoogleSignInClient mGoogleSignInClient;
    private ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        String bgcolor = "#1B1B6B";
        ActionBar actionBar = getSupportActionBar();
        actionBar.setBackgroundDrawable(new ColorDrawable(Color.parseColor(bgcolor)));
        this.getWindow().setStatusBarColor(Color.parseColor(bgcolor));
        setContentView(R.layout.activity_login);


        email = findViewById(R.id.emailedt);
        password = findViewById(R.id.passedt);
        login = findViewById(R.id.loginbtn);
        register = findViewById(R.id.registertxt);
        forgottxt = findViewById(R.id.forgettxt);
        //awesomeValidation.addValidation(this, R.id.regemail, Patterns.EMAIL_ADDRESS, R.string.emailerror);
        progressDialog = new ProgressDialog(this);

        forgottxt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent forgotIntent = new Intent(Login.this, Forgot_Password.class);
                startActivity(forgotIntent);
            }
        });

        // Configure Google Sign In
        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestIdToken(getString(R.string.default_web_client_id))
                .requestEmail()
                .build();
        mGoogleSignInClient = GoogleSignIn.getClient(this, gso);
        // Initialize Firebase Auth
        mAuth = FirebaseAuth.getInstance();

        SignInButton signInButton=(SignInButton)findViewById(R.id.sign_in_button);
        signInButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                signIn();
            }
        });

        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent registerIntent = new Intent(Login.this, Registration.class);
                startActivity(registerIntent);
            }
        });
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                progressDialog.setMessage("Logining Please Wait...");


                mail=email.getText().toString();
                pass=password.getText().toString();

                if (email.length() == 0) {
                    email.setError("Enter your email");
                    email.requestFocus();
                } else if (password.length() == 0) {
                    password.setError("Enter your password");
                    password.requestFocus();
                } else{
                    progressDialog.show();
                    mAuth.signInWithEmailAndPassword(email.getText().toString(), password.getText().toString())
                            .addOnCompleteListener(Login.this, new OnCompleteListener<AuthResult>() {
                                @Override
                                public void onComplete(@NonNull Task<AuthResult> task) {
                                    if (task.isSuccessful()) {

                                        // Sign in success, update UI with the signed-in user's information
                                        Log.d(TAG, "signInWithEmail:success");
                                        FirebaseUser user = mAuth.getCurrentUser();
                                        if(user.isEmailVerified()) {
                                            Intent i = new Intent(Login.this, Drawer.class);
                                            startActivity(i);
                                            finish();
                                            progressDialog.dismiss();
                                        }else{
                                            FirebaseAuth.getInstance().signOut();
                                            progressDialog.dismiss();

                                            AlertDialog.Builder dlgAlertverifyemail  = new AlertDialog.Builder(Login.this);
                                            dlgAlertverifyemail.setMessage("Please verify your email account. ");
                                            dlgAlertverifyemail.setTitle("Error Message");
                                            dlgAlertverifyemail.setIcon(R.drawable.ic_warning_black_24dp);
                                            dlgAlertverifyemail.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                                                @Override
                                                public void onClick(DialogInterface dialogInterface, int i) {

                                                }
                                            });
                                            dlgAlertverifyemail.create().show();
                                        }

                                    } else {

                                        progressDialog.dismiss();

                                        // If sign in fails, display a message to the user.
                                        Log.w(TAG, "signInWithEmail:failure", task.getException());
                                        AlertDialog.Builder dlgAlert  = new AlertDialog.Builder(Login.this);
                                        dlgAlert.setMessage("Wrong password or email id");
                                        dlgAlert.setTitle("Error Message");
                                        dlgAlert.setIcon(R.drawable.ic_warning_black_24dp);
                                        dlgAlert.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                                            @Override
                                            public void onClick(DialogInterface dialogInterface, int i) {
                                                /*email.setText("");*/
                                                password.getText().clear();
                                                email.setFocusable(true);
                                                email.requestFocus();
                                            }
                                        });
                                        dlgAlert.create().show();

                                    }
                                    // ...
                                }
                            });
                }
            }
        });
    }

    // [START signin]
    private void signIn() {
        progressDialog.setMessage("Registering Please Wait...");


        Intent signInIntent = mGoogleSignInClient.getSignInIntent();
        startActivityForResult(signInIntent, RC_SIGN_IN);
    }
    // [END signin]

    // [START onactivityresult]
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        progressDialog.show();
        // Result returned from launching the Intent from GoogleSignInApi.getSignInIntent(...);
        if (requestCode == RC_SIGN_IN) {
            Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(data);
            try {
                // Google Sign In was successful, authenticate with Firebase
                GoogleSignInAccount account = task.getResult(ApiException.class);
                firebaseAuthWithGoogle(account);
            } catch (ApiException e) {
                // Google Sign In failed, update UI appropriately
                Log.w(TAG, "Google sign in failed", e);
                // [START_EXCLUDE]

                // [END_EXCLUDE]
            }
        }
    }
    // [END onactivityresult]

    // [START auth_with_google]
    private void firebaseAuthWithGoogle(final GoogleSignInAccount acct) {
        Log.d(TAG, "firebaseAuthWithGoogle:" + acct.getId());
        // [START_EXCLUDE silent]
        /*showProgressDialog();*/
        // [END_EXCLUDE]

        final AuthCredential credential = GoogleAuthProvider.getCredential(acct.getIdToken(), null);
        mAuth.signInWithCredential(credential)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        String uid=null;
                        if (task.isSuccessful()) {
                            // Sign in success, update UI with the signed-in user's information
                            Log.d(TAG, "signInWithCredential:success");
                            FirebaseUser user = mAuth.getCurrentUser();
                            if (user != null) {
                                uid = mAuth.getCurrentUser().getUid();
                                DatabaseReference query= FirebaseDatabase.getInstance()
                                        .getReference()
                                        .child("User").child(uid);
                                final String finalUid = uid;
                                if (finalUid!= null) {
                                    query.addListenerForSingleValueEvent(new ValueEventListener() {
                                        @Override
                                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                            if (dataSnapshot.getValue() == null) {
                                                register1.setName(acct.getDisplayName());
                                                register1.setEmail(acct.getEmail());
                                                register1.setDob("");
                                                register1.setPhone("");
                                                db= FirebaseDatabase.getInstance().getReference().child("User");
                                                db.child(finalUid).setValue(register1);

                                                // The child doesn't exist
                                            }
                                            else{

                                            }
                                            progressDialog.dismiss();
                                            finish();
                                            startActivity(new Intent(getApplicationContext(), Drawer.class));
                                        }

                                        @Override
                                        public void onCancelled(@NonNull DatabaseError databaseError) {

                                        }
                                    } );


                                } else {
                                    progressDialog.dismiss();
                                    //display some message here
                                    Toast.makeText(Login.this, "Registration Error", Toast.LENGTH_LONG).show();
                                }

                            } else {
                                progressDialog.dismiss();
                                //display some message here
                                Toast.makeText(Login.this, "Registration Error", Toast.LENGTH_LONG).show();
                            }

                            progressDialog.dismiss();

                        } else {
                            progressDialog.dismiss();
                            // If sign in fails, display a message to the user.
                            Log.w(TAG, "signInWithCredential:failure", task.getException());
                            Toast.makeText(Login.this, "Authentication Failed.", Toast.LENGTH_SHORT).show();

                        }

                        // [START_EXCLUDE]
//                        hideProgressDialog();
                        // [END_EXCLUDE]
                    }
                });
    }
    // [END auth_with_google]


    /*private void updateUI(FirebaseUser user) {

        if (user != null) {



        } else {

        }
    }
*/
    /*
    @Override
    public void onStart() {
        super.onStart();
        // Check if user is signed in (non-null) and update UI accordingly.
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if(currentUser!=null){
            Intent i=new Intent(Login.this,Drawer.class);
            startActivity(i);
            finish();
        }
    }*/

}
