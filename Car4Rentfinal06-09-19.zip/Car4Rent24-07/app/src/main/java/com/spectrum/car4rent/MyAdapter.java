package com.spectrum.car4rent;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

import java.util.List;


public class MyAdapter extends RecyclerView.Adapter<MyAdapter.ViewHolder>{
    private final Context context;
    private List<CarView> listData;
    CarView ld;
    int activity;

    public MyAdapter(Context context, List<CarView> listData,int activity) {
        this.context=context;
        this.listData = listData;
        this.activity=activity;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.car_view,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, final int position) {

        ld=listData.get(position);
        Log.d("Home", "starting fetch"+position);
        holder.CarTitle.setText(ld.getModel());
        Picasso.get().load(ld.image).placeholder(R.drawable.dummy_car).fit().centerCrop().into(holder.CarImage);
        holder.CarFuel.setText(ld.getFuel());
        holder.CarMileage.setText(ld.getMileage());
        holder.CarYear.setText(ld.getYear());
        holder.CarRenthr.setText(("Rs. " +ld.getRenthour()+ " /hour"));
        /*holder.root.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String key= ld.getRegno();
                Log.e("key",""+key);

            }
        });*/
    }



    @Override
    public int getItemCount() {
        return listData.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        public RelativeLayout root;
        public TextView CarTitle, CarMileage, CarFuel, CarModel, CarYear, CarRenthr;
        public ImageView CarImage;
        private Bitmap bitmap;

        public ViewHolder(View itemView) {
            super(itemView);
            root = itemView.findViewById(R.id.car_root_layout);
            CarTitle = itemView.findViewById(R.id.car_title);
            CarImage = itemView.findViewById(R.id.car_image);
            CarFuel = itemView.findViewById(R.id.car_fuel);
            CarMileage = itemView.findViewById(R.id.car_mileage);
            CarRenthr = itemView.findViewById(R.id.car_hrprice);
            CarYear = itemView.findViewById(R.id.car_year);

            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {
            int position=getLayoutPosition();
            CarView carView= listData.get(position);
            String key=carView.getRegno();
            //cardetails(key,false);


            Intent g=new Intent(view.getContext(), Car__details.class);
            g.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            g.putExtra("key",key);
            g.putExtra("reg",false);
            context.startActivity(g);
        }
    }

}