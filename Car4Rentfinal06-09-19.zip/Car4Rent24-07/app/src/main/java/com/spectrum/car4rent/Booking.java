package com.spectrum.car4rent;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

@SuppressWarnings("ALL")
public class Booking extends AppCompatActivity {
    private TextView start,end,start_location,du;
    private Calendar calendar;
    int year,month,day,hour,minute,year1,month1,day1, numday,numhour,rate,rentday,renthour;
    private Date startb,start_date,end_date;
    private Format formatter;
    private int Req_i=111;
    TextView CarTitle,Purpose;
    ImageView CarImage;
    String purp,key,premium;
    private FirebaseAuth firebaseAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        String bgcolor = "#1B1B6B";
        ActionBar actionBar = getSupportActionBar();
        actionBar.setBackgroundDrawable(new ColorDrawable(Color.parseColor(bgcolor)));
        actionBar.setTitle("");
        actionBar.setDisplayHomeAsUpEnabled(true);
        this.getWindow().setStatusBarColor(Color.parseColor(bgcolor));

        setContentView(R.layout.activity_booking);

        Intent k=getIntent();

        key=k.getStringExtra("key");
Log.e("error",key);
        firebaseAuth= FirebaseAuth.getInstance();
        final Book book=new Book();
        Button bookbtn = (Button) findViewById(R.id.bkcar_btn_book);
        CarTitle=findViewById(R.id.bkcar_tv_title);
        CarImage=findViewById(R.id.bkcar_iv_image);
        Purpose=findViewById(R.id.bkcar_tv_purpose);
        start = (TextView) findViewById(R.id.bkcar_tv_startdate);
        end = (TextView) findViewById(R.id.bkcar_tv_enddate);
        du=(TextView) findViewById(R.id.bkcar_tv_duration);
//TODO        start_location = (TextView) findViewById(R.id.bkcar_tv_pickuplocation);
        premium="No";

        DatabaseReference nm = FirebaseDatabase.getInstance().getReference("cars/"+key);
        nm.addListenerForSingleValueEvent(new ValueEventListener() {
                                              @Override
                                              public void onDataChange(DataSnapshot dataSnapshot) {
                                                  if (dataSnapshot.exists()) {
                                                      CarView ld = dataSnapshot.getValue(CarView.class);
                                                      CarTitle.setText(ld.getModel());
                                                      Picasso.get().load(ld.image).placeholder(R.drawable.dummy_car).fit().centerCrop().into(CarImage);
                                                      rentday= Integer.parseInt(ld.getRentday());
                                                      renthour= Integer.parseInt(ld.getRenthour());
                                                      rate=renthour;
                                                      du.setText("1 hour ( Rs."+renthour+" ) ");
                                                      premium=ld.getPremium();
                                                      Log.e("premium2",premium);
                                                      Log.e("premium1",premium);
                                                      if(!premium.equals("Yes")){
                                                          Log.e("premium if no",premium);
                                                          calendar = Calendar.getInstance();
                                                          start_date = new Date(calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH)+2, calendar.get(Calendar.HOUR_OF_DAY), calendar.get(Calendar.MINUTE), 0);
                                                          formatter = new SimpleDateFormat("dd/MM/yy h:mm a");
                                                          start.setText(new StringBuilder().append(formatter.format(start_date)));


                                                          end_date= new Date(calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH)+2, calendar.get(Calendar.HOUR_OF_DAY) + 1, calendar.get(Calendar.MINUTE), 0);
                                                          startb=new Date(calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH)+2, calendar.get(Calendar.HOUR_OF_DAY) , calendar.get(Calendar.MINUTE)+59, 0);

                                                          formatter = new SimpleDateFormat("dd/MM/yy h:mm a");
                                                          end.setText(new StringBuilder().append(formatter.format(end_date)));

                                                          start.setOnClickListener(new View.OnClickListener() {
                                                              @Override
                                                              public void onClick(View view) {
                                                                  calendar = Calendar.getInstance();
                                                                  DatePickerDialog datePickerDialog = new DatePickerDialog(Booking.this,
                                                                          new DatePickerDialog.OnDateSetListener() {

                                                                              @Override
                                                                              public void onDateSet(DatePicker view, int i, int i1, int i2) {
                                                                                  day1 = i2;
                                                                                  month1 = i1;
                                                                                  year1 = i;
                                                                                  TimePickerDialog timePickerDialog = new TimePickerDialog(Booking.this,android.R.style.Theme_Holo_Light_Dialog_NoActionBar,
                                                                                          new TimePickerDialog.OnTimeSetListener() {

                                                                                              @Override
                                                                                              public void onTimeSet(TimePicker view, int hourOfDay,
                                                                                                                    int minute1) {

                                                                                                  startb=new Date(year1, month1, day1, hourOfDay, minute1+59, 0);
                                                                                                  start_date= new Date(year1, month1, day1, hourOfDay, minute1, 0);

                                                                                                  if(end_date.after(start_date)){
                                                                                                      rate=0;
                                                                                                      formatter = new SimpleDateFormat("dd/MM/yy h:mm a");
                                                                                                      start.setText(new StringBuilder().append(formatter.format(start_date)));
                                                                                                      numday= (int) ((end_date.getTime()-start_date.getTime())/(24*60*60*1000));
                                                                                                      String dur="";
                                                                                                      if(numday>0) {
                                                                                                          dur = getResources().getQuantityString(R.plurals.duration_day, numday, numday);

                                                                                                      }
                                                                                                      numhour=end_date.getHours()-start_date.getHours();
                                                                                                      String dur1=getResources().getQuantityString(R.plurals.duration_hour,numhour,numhour);
                                                                                                      if(numday==0&&numhour<12){
                                                                                                          rate=renthour*numhour;
                                                                                                      }
                                                                                                      else if(numhour>=12){
                                                                                                          rate=rentday*(numday+1);
                                                                                                      }else{
                                                                                                          rate=rentday*numday;
                                                                                                      }
                                                                                                      du.setText(dur+"  "+dur1+"( Rs."+rate+" ) ");

                                                                                                  }
                                                                                                  else{
                                                                                                      formatter = new SimpleDateFormat("dd/MM/yy h:mm a");
                                                                                                      start.setText(new StringBuilder().append(formatter.format(start_date)));
                                                                                                  }
                                                                                              }
                                                                                          }, hour,minute, false);
                                                                                  timePickerDialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
                                                                                  timePickerDialog.setTitle("Select Time ");
                                                                                  timePickerDialog.show();
                                                                              }
                                                                          }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH));
                                                                  calendar.add(Calendar.DAY_OF_MONTH,+2);
                                                                  long minDate=calendar.getTimeInMillis()-1000;
                                                                  calendar.add(Calendar.MONTH,+3);
                                                                  long threeMonthAhead=calendar.getTimeInMillis()-1000;
                                                                  datePickerDialog.getDatePicker().setMaxDate(threeMonthAhead);
                                                                  datePickerDialog.getDatePicker().setMinDate(minDate);
                                                                  datePickerDialog.show();
                                                              }
                                                          });

                                                          end.setOnClickListener(new View.OnClickListener() {
                                                              @Override
                                                              public void onClick(View view) {
                                                                  calendar = Calendar.getInstance();
                                                                  DatePickerDialog datePickerDialog = new DatePickerDialog(Booking.this,
                                                                          new DatePickerDialog.OnDateSetListener() {

                                                                              @Override
                                                                              public void onDateSet(DatePicker view, int i, int i1, int i2) {
                                                                                  day1 = i2;
                                                                                  month1 = i1;
                                                                                  year1 = i;
                                                                                  TimePickerDialog timePickerDialog = new TimePickerDialog(Booking.this,android.R.style.Theme_Holo_Light_Dialog_NoActionBar,
                                                                                          new TimePickerDialog.OnTimeSetListener() {

                                                                                              @Override
                                                                                              public void onTimeSet(TimePicker view, int hourOfDay,
                                                                                                                    int minute1) {
                                                                                                  end_date = new Date(year1, month1, day1, hourOfDay, minute1, 0);
                                                                                                  if(end_date.after(startb)){
                                                                                                      formatter = new SimpleDateFormat("dd/MM/yy h:mm a");
                                                                                                      end.setText(new StringBuilder().append(formatter.format(end_date)));
                                                                                                      numday= (int) ((end_date.getTime()-start_date.getTime())/(24*60*60*1000));
                                                                                                      String dur="";
                                                                                                      if(numday>0) {
                                                                                                          dur = getResources().getQuantityString(R.plurals.duration_day, numday, numday);
                                                                                                      }
                                                                                                      numhour=end_date.getHours()-start_date.getHours();
                                                                                                      String dur1=getResources().getQuantityString(R.plurals.duration_hour,numhour,numhour);
                                                                                                      if(numday==0&&numhour<10){
                                                                                                          rate=renthour*numhour;
                                                                                                      }
                                                                                                      else if(numhour>=10){
                                                                                                          rate=rentday*(numday+1);
                                                                                                      }else{
                                                                                                          rate=rentday*numday;
                                                                                                      }
                                                                                                      du.setText(dur+"  "+dur1+"( Rs."+rate+" ) ");
                                                                                                  }
                                                                                              }
                                                                                          }, start_date.getHours()+1,start_date.getMinutes(), false);
                                                                                  timePickerDialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
                                                                                  timePickerDialog.setTitle("Select Time ");
                                                                                  timePickerDialog.show();
                                                                              }
                                                                          }, start_date.getYear(),start_date.getMonth(),start_date.getDate());

                                                                  Calendar cal= Calendar.getInstance();
                                                                  cal.set(start_date.getYear(),start_date.getMonth(),start_date.getDate(),start_date.getHours(),start_date.getMinutes(),0);
                                                                  long minDate=cal.getTimeInMillis()-1000;
                                                                  cal.add(Calendar.MONTH,+1);
                                                                  long maxDate=cal.getTimeInMillis()-1000;
                                                                  datePickerDialog.getDatePicker().setMaxDate(maxDate);
                                                                  datePickerDialog.getDatePicker().setMinDate(minDate);
                                                                  datePickerDialog.show();


                                                              }
                                                          });
                                                      }else{
                                                          Log.e("premium if yes",premium);
                                                          calendar = Calendar.getInstance();
                                                          start_date = new Date(calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH), calendar.get(Calendar.HOUR_OF_DAY), calendar.get(Calendar.MINUTE), 0);
                                                          formatter = new SimpleDateFormat("dd/MM/yy h:mm a");
                                                          start.setText(new StringBuilder().append(formatter.format(start_date)));


                                                          end_date= new Date(calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH), calendar.get(Calendar.HOUR_OF_DAY) +1, calendar.get(Calendar.MINUTE), 0);
                                                          startb=new Date(calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH), calendar.get(Calendar.HOUR_OF_DAY) , calendar.get(Calendar.MINUTE)+59, 0);

                                                          formatter = new SimpleDateFormat("dd/MM/yy h:mm a");
                                                          end.setText(new StringBuilder().append(formatter.format(end_date)));

                                                          start.setOnClickListener(new View.OnClickListener() {
                                                              @Override
                                                              public void onClick(View view) {
                                                                  calendar = Calendar.getInstance();
                                                                  DatePickerDialog datePickerDialog = new DatePickerDialog(Booking.this,
                                                                          new DatePickerDialog.OnDateSetListener() {

                                                                              @Override
                                                                              public void onDateSet(DatePicker view, int i, int i1, int i2) {
                                                                                  day1 = i2;
                                                                                  month1 = i1;
                                                                                  year1 = i;
                                                                                  TimePickerDialog timePickerDialog = new TimePickerDialog(Booking.this,android.R.style.Theme_Holo_Light_Dialog_NoActionBar,
                                                                                          new TimePickerDialog.OnTimeSetListener() {

                                                                                              @Override
                                                                                              public void onTimeSet(TimePicker view, int hourOfDay,
                                                                                                                    int minute1) {

                                                                                                  startb=new Date(year1, month1, day1, hourOfDay, minute1+59, 0);
                                                                                                  start_date= new Date(year1, month1, day1, hourOfDay, minute1, 0);

                                                                                                  if(end_date.after(start_date)){
                                                                                                      rate=0;
                                                                                                      formatter = new SimpleDateFormat("dd/MM/yy h:mm a");
                                                                                                      start.setText(new StringBuilder().append(formatter.format(start_date)));
                                                                                                      numday= (int) ((end_date.getTime()-start_date.getTime())/(24*60*60*1000));
                                                                                                      String dur="";
                                                                                                      if(numday>0) {
                                                                                                          dur = getResources().getQuantityString(R.plurals.duration_day, numday, numday);

                                                                                                      }
                                                                                                      numhour=end_date.getHours()-start_date.getHours();
                                                                                                      String dur1=getResources().getQuantityString(R.plurals.duration_hour,numhour,numhour);
                                                                                                      if(numday==0&&numhour<12){
                                                                                                          rate=renthour*numhour;
                                                                                                      }
                                                                                                      else if(numhour>=12){
                                                                                                          rate=rentday*(numday+1);
                                                                                                      }else{
                                                                                                          rate=rentday*numday;
                                                                                                      }
                                                                                                      du.setText(dur+"  "+dur1+"( Rs."+rate+" ) ");

                                                                                                  }
                                                                                                  else{
                                                                                                      formatter = new SimpleDateFormat("dd/MM/yy h:mm a");
                                                                                                      start.setText(new StringBuilder().append(formatter.format(start_date)));
                                                                                                  }
                                                                                              }
                                                                                          }, hour,minute, false);
                                                                                  timePickerDialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
                                                                                  timePickerDialog.setTitle("Select Time ");
                                                                                  timePickerDialog.show();
                                                                              }
                                                                          }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH));

                                                                  long minDate=calendar.getTimeInMillis()-1000;
                                                                  calendar.add(Calendar.MONTH,+3);
                                                                  long threeMonthAhead=calendar.getTimeInMillis()-1000;
                                                                  datePickerDialog.getDatePicker().setMaxDate(threeMonthAhead);
                                                                  datePickerDialog.getDatePicker().setMinDate(minDate);
                                                                  datePickerDialog.show();
                                                              }
                                                          });

                                                          end.setOnClickListener(new View.OnClickListener() {
                                                              @Override
                                                              public void onClick(View view) {
                                                                  calendar = Calendar.getInstance();
                                                                  DatePickerDialog datePickerDialog = new DatePickerDialog(Booking.this,
                                                                          new DatePickerDialog.OnDateSetListener() {

                                                                              @Override
                                                                              public void onDateSet(DatePicker view, int i, int i1, int i2) {
                                                                                  day1 = i2;
                                                                                  month1 = i1;
                                                                                  year1 = i;
                                                                                  TimePickerDialog timePickerDialog = new TimePickerDialog(Booking.this,android.R.style.Theme_Holo_Light_Dialog_NoActionBar,
                                                                                          new TimePickerDialog.OnTimeSetListener() {

                                                                                              @Override
                                                                                              public void onTimeSet(TimePicker view, int hourOfDay,
                                                                                                                    int minute1) {
                                                                                                  end_date = new Date(year1, month1, day1, hourOfDay, minute1, 0);
                                                                                                  if(end_date.after(startb)){
                                                                                                      formatter = new SimpleDateFormat("dd/MM/yy h:mm a");
                                                                                                      end.setText(new StringBuilder().append(formatter.format(end_date)));
                                                                                                      numday= (int) ((end_date.getTime()-start_date.getTime())/(24*60*60*1000));
                                                                                                      String dur="";
                                                                                                      if(numday>0) {
                                                                                                          dur = getResources().getQuantityString(R.plurals.duration_day, numday, numday);
                                                                                                      }
                                                                                                      numhour=end_date.getHours()-start_date.getHours();
                                                                                                      String dur1=getResources().getQuantityString(R.plurals.duration_hour,numhour,numhour);
                                                                                                      if(numday==0&&numhour<10){
                                                                                                          rate=renthour*numhour;
                                                                                                      }
                                                                                                      else if(numhour>=10){
                                                                                                          rate=rentday*(numday+1);
                                                                                                      }else{
                                                                                                          rate=rentday*numday;
                                                                                                      }
                                                                                                      du.setText(dur+"  "+dur1+"( Rs."+rate+" ) ");
                                                                                                  }
                                                                                              }
                                                                                          }, start_date.getHours()+1,start_date.getMinutes(), false);
                                                                                  timePickerDialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
                                                                                  timePickerDialog.setTitle("Select Time ");
                                                                                  timePickerDialog.show();
                                                                              }
                                                                          }, start_date.getYear(),start_date.getMonth(),start_date.getDate());

                                                                  Calendar cal= Calendar.getInstance();
                                                                  cal.set(start_date.getYear(),start_date.getMonth(),start_date.getDate(),start_date.getHours(),start_date.getMinutes(),0);
                                                                  long minDate=cal.getTimeInMillis()-1000;
                                                                  cal.add(Calendar.MONTH,+1);
                                                                  long maxDate=cal.getTimeInMillis()-1000;
                                                                  datePickerDialog.getDatePicker().setMaxDate(maxDate);
                                                                  datePickerDialog.getDatePicker().setMinDate(minDate);
                                                                  datePickerDialog.show();


                                                              }
                                                          });
                                                      }

                                                  }

                                              }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });



        bookbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
            if(start_date.before(end_date)) {
                final long startDate = start_date.getTime();
                final long endDate = end_date.getTime();
                purp = Purpose.getText().toString();
                book.setKey(key);
                book.setStart(startDate);
                book.setEnd(endDate);
                book.setPurpose(purp);
                book.setRate(rate);
                String uid = firebaseAuth.getCurrentUser().getUid().toString();
                book.setBooker(uid);
                DatabaseReference bk1 = FirebaseDatabase.getInstance().getReference().child("book").child(key);
                Log.e("error", key);
                bk1.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        if (dataSnapshot.exists()) {
                            int i = 0;
                            for (DataSnapshot npd : dataSnapshot.getChildren()) {
                                Book val = npd.getValue(Book.class);
                                if ((startDate < val.getStart() && endDate < val.getStart()) || startDate > val.getEnd() && endDate > val.getEnd()) {
                                    i++;
                                    continue;
                                } else
                                    break;
                            }
                            if (i == dataSnapshot.getChildrenCount()) {
                                DatabaseReference bk = FirebaseDatabase.getInstance().getReference().child("book");
                                bk.child(key).child(String.valueOf(startDate)).setValue(book, new DatabaseReference.CompletionListener() {
                                    @Override
                                    public void onComplete(@Nullable DatabaseError databaseError, @NonNull DatabaseReference databaseReference) {
                                        if (databaseError != null) {
                                            Log.e("error", "Data could not be saved. " + databaseError.getMessage());
                                        } else {
                                            Log.e("succes", "Data saved successfully.");
                                            Toast.makeText(getApplicationContext(), "Car booked successfully", Toast.LENGTH_SHORT).show();
                                            Intent intent = new Intent(Booking.this, Drawer.class);
                                            startActivity(intent);
                                            finish();
                                        }
                                    }


                                });
                            } else {
                                AlertDialog.Builder dlgAlertverifyemail = new AlertDialog.Builder(Booking.this);
                                dlgAlertverifyemail.setMessage("Sorry , the car is not available on that time range");
                                dlgAlertverifyemail.setTitle("Car is already booked!!");
                                dlgAlertverifyemail.setIcon(R.drawable.ic_warning_black_24dp);
                                dlgAlertverifyemail.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialogInterface, int i) {

                                    }
                                });
                                dlgAlertverifyemail.create().show();

                            }
                        }else{
                            DatabaseReference bk = FirebaseDatabase.getInstance().getReference().child("book");
                            bk.child(key).child(String.valueOf(startDate)).setValue(book, new DatabaseReference.CompletionListener() {
                                @Override
                                public void onComplete(@Nullable DatabaseError databaseError, @NonNull DatabaseReference databaseReference) {
                                    if (databaseError != null) {
                                        Log.e("error", "Data could not be saved. " + databaseError.getMessage());
                                    } else {
                                        Log.e("succes", "Data saved successfully.");
                                        Toast.makeText(getApplicationContext(), "Car booked successfully", Toast.LENGTH_SHORT).show();
                                        Intent intent = new Intent(Booking.this, Drawer.class);
                                        startActivity(intent);
                                        finish();
                                    }
                                }


                            });
                        }
                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {

                    }
                });
            }else{
                AlertDialog.Builder dlgAlertverifyemail = new AlertDialog.Builder(Booking.this);
                dlgAlertverifyemail.setMessage("Please select a end date greater than start date");
                dlgAlertverifyemail.setTitle("starting date is greater than end date");
                dlgAlertverifyemail.setIcon(R.drawable.ic_warning_black_24dp);
                dlgAlertverifyemail.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                    }
                });
                dlgAlertverifyemail.create().show();

            }
            }
        });




        /*start_location.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                *//*Intent i=new Intent(Booking.this,Get_Place.class);
                startActivityForResult(i,1);
                *//*
            }
        });*/
    }
/*
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        if(resultCode == RESULT_OK){
            start_location.setText(data.getIntExtra("result",0)+"");
        }

    }*/

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}
