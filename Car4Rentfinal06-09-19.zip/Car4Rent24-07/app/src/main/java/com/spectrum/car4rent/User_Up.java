package com.spectrum.car4rent;

public class User_Up {

    String userId,img;

    public User_Up(){

    }

    public User_Up(String userId,String img){
        this.userId = userId;
        this.img = img;
    }

    public String getUserId(){
        return userId;
    }

    public String getImg(){
        return img;
    }

    public void setUserId(String userId){
        this.userId = userId;
    }

    public void setImg(String img){
        this.img = img;
    }
}
