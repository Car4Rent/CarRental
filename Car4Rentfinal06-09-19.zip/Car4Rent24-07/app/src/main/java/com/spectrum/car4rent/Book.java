package com.spectrum.car4rent;

class Book {
    long start, end;
    String purpose;
    int rate;
    String booker,key;


    public Book(){}
    public Book(long start,long end,String purpose,int rate,String booker,String key){
        this.booker=booker;
        this.end=end;
        this.start=start;
        this.purpose=purpose;
        this.rate=rate;
        this.key=key;

    }

    public String getPurpose(){
        return purpose;
    }
    public  long getStart(){
        return start;
    }
    public  long getEnd(){
        return  end;
    }
    public  int getRate(){
        return rate;
    }

    public String getBooker() {
        return booker;
    }

    public String getKey() { return key; }

    public void setEnd(long end) {
        this.end = end;
    }

    public void setPurpose(String purpose) {
        this.purpose = purpose;
    }

    public void setRate(int rate) {
        this.rate = rate;
    }

    public void setStart(long start) {
        this.start = start;
    }

    public void setBooker(String uid) {
        this.booker=uid;
    }

    public void setKey(String key) {
        this.key=key;
    }
}
