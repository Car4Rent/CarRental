package com.spectrum.car4rent;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class Popular_Brands extends RecyclerView.Adapter<Popular_Brands.ViewHolderPopular> {
    ArrayList name;
    ArrayList logo1;
    Context context;

    public Popular_Brands(Context context,ArrayList name, ArrayList logo1){
        this.context=context;
        this.name=name;
        this.logo1=logo1;
    }


    @Override
    public ViewHolderPopular onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.brand_name, parent, false);
        ViewHolderPopular v=new ViewHolderPopular(view);
        return v;
    }





    public void onBindViewHolder(@NonNull ViewHolderPopular holder, final int position) {
        holder.txtTitle.setText((CharSequence) name.get(position));
        holder.logo.setImageResource((Integer) logo1.get(position));
        Filter.flagbrand[position]=false;
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(Filter.flagbrand[position]){
                    Filter.flagbrand[position]=false;
                    view.findViewById(R.id.brand_rv_layout).setBackgroundResource(R.drawable.filter_rect_btn);
                }else{
                    Filter.flagbrand[position]=true;
                    view.findViewById(R.id.brand_rv_layout).setBackgroundResource(R.drawable.filter_rect_btn_on);
                }

            }
        });
    }

    @Override
    public int getItemCount() {
        return name.size();
    }
    public class ViewHolderPopular extends RecyclerView.ViewHolder {
        LinearLayout root;
        TextView txtTitle;
        ImageView logo;


        public ViewHolderPopular(View itemView) {
            super(itemView);
            /*root = itemView.findViewById(R.id.brand_rv_layout);*/
            txtTitle = itemView.findViewById(R.id.brand_tv_title);
            logo = itemView.findViewById(R.id.brand_iv_image);
        }
    }
}

