package com.spectrum.car4rent;

import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import com.basgeekball.awesomevalidation.AwesomeValidation;
import com.basgeekball.awesomevalidation.ValidationStyle;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.Calendar;

public class Registration extends AppCompatActivity {

    EditText regname, regphone, regdob, regemail, regpass, regcpass;
    Button regsignup;
    ProgressBar progressBar;
    int year;
    int month;
    int day;
    long max,date;
    private AwesomeValidation awesomeValidation;
    final Register register1=new Register();
    DatabaseReference db;
    private FirebaseAuth firebaseAuth;
    private ProgressDialog progressDialog;
    String MobilePattern = "[0-9]{10}";
//    String namePattern="  [a-zA-Z]+\\\\.?\"  ";
//    String namePattern="/^[a-zA-Z][a-zA-Z\\s]+$/";
//    String namePattern="[a-zA-Z]+\\.?";
//    String namePattern="^[_A-z0-9]*((-|\\s)*[_A-z0-9])*$";

    String namePattern="[a-zA-Z ]+";
    //String email1 = email.getText().toString().trim();
    String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        String bgcolor = "#1B1B6B";
        ActionBar actionBar = getSupportActionBar();
        actionBar.setBackgroundDrawable(new ColorDrawable(Color.parseColor(bgcolor)));
        this.getWindow().setStatusBarColor(Color.parseColor(bgcolor));
        setContentView(R.layout.activity_registration);
        regdob = findViewById(R.id.regdob);
        regname = findViewById(R.id.regname);
        regphone = findViewById(R.id.regphone);
        regpass = findViewById(R.id.regpass);
        regemail = findViewById(R.id.regemail);
        regcpass = findViewById(R.id.regcpass);
        regsignup = findViewById(R.id.regsignup);
        db= FirebaseDatabase.getInstance().getReference().child("User");
        firebaseAuth= FirebaseAuth.getInstance();
        progressDialog = new ProgressDialog(this);




        awesomeValidation = new AwesomeValidation(ValidationStyle.BASIC);
        regphone.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View view, boolean b) {
                if (regname.length() == 0) {
                    // submitForm();
                }
            }
        });
        regdob.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Calendar calendar = Calendar.getInstance();
                year = calendar.get(Calendar.YEAR);
                month = calendar.get(Calendar.MONTH);
                day = calendar.get(Calendar.DAY_OF_MONTH);
                DatePickerDialog datePickerDialog = new DatePickerDialog(Registration.this,
                        new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                                regdob.setText(day + "/" + (month + 1) + "/" + year);
                            }
                        }, year, month, day);
                date = 1970;
                Calendar cal = Calendar.getInstance();
                cal.add(Calendar.YEAR, -18);
                // cal.add(Calendar.DAY_OF_MONTH,+1);
                max = cal.getTimeInMillis();
                datePickerDialog.getDatePicker().setMinDate(date);
                datePickerDialog.getDatePicker().setMaxDate(max);
                datePickerDialog.show();
            }
        });
        regsignup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                progressDialog.setMessage("Registering Please Wait...");
                final String name = regname.getText().toString();
                final String phone = regphone.getText().toString();
                final String dob = regdob.getText().toString();
                final String email = regemail.getText().toString();
                final String password = regpass.getText().toString();
                final String cpassword = regcpass.getText().toString();
                if (!name.matches(namePattern)) {
                    regname.setError("Enter a name");
                    regname.requestFocus();
                } else if (!phone.matches(MobilePattern)) {
                    regphone.setError("Enter a valid phone number");
                    regphone.requestFocus();
                } else if (TextUtils.isEmpty(dob)) {
                    regdob.setError("Select your date of birth");
                    regdob.requestFocus();
                } else if(!email.matches(emailPattern)) {
                    regemail.setError("Enter a valid email ");
                    regemail.requestFocus();
                } else if (TextUtils.isEmpty(password) || (password.length()<6)) {
                    regpass.setError("Enter password grater than 6 character ");
                    regpass.requestFocus();
                } else if (TextUtils.isEmpty(cpassword)&&(cpassword.length()<6)) {
                    regcpass.setError("Confirm your password");
                    regcpass.requestFocus();
                } else if (!regpass.getText().toString().equals(regcpass.getText().toString())) {
                    regcpass.setError("Confirm your password");
                    regcpass.requestFocus();
                } else if (regpass.getText().toString().equals(regcpass.getText().toString())) {
                    progressDialog.show();
                    firebaseAuth.createUserWithEmailAndPassword(email, password)
                            .addOnCompleteListener(Registration.this, new OnCompleteListener<AuthResult>() {
                                @Override
                                public void onComplete(@NonNull Task<AuthResult> task) {
                                    //checking if success
                                    String uid = null;
                                    if (task.isSuccessful()) {
                                        final FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
                                        if (user != null) {
                                            uid = firebaseAuth.getCurrentUser().getUid();
                                            if (uid != null) {
                                                register1.setName(name);
                                                register1.setPhone(phone);
                                                register1.setDob(dob);
                                                register1.setEmail(email);
                                                db.child(uid).setValue(register1);
                                                user.sendEmailVerification()
                                                        .addOnCompleteListener(Registration.this, new OnCompleteListener() {
                                                            @Override
                                                            public void onComplete(@NonNull Task task) {
                                                                // Re-enable button

                                                                if (task.isSuccessful()) {
                                                                    Toast.makeText(Registration.this,
                                                                            "Verification email sent to " + user.getEmail(),
                                                                            Toast.LENGTH_SHORT).show();
                                                                } else {
                                                                    Log.e("email", "sendEmailVerification", task.getException());
                                                                    Toast.makeText(Registration.this,
                                                                            "Failed to send verification email.",
                                                                            Toast.LENGTH_SHORT).show();
                                                                }
                                                            }
                                                        });
                                                FirebaseAuth.getInstance().signOut();
                                                finish();
                                                startActivity(new Intent(getApplicationContext(), Login.class));
                                            } else {
                                                //display some message here
                                                Toast.makeText(Registration.this, "Registration Error", Toast.LENGTH_LONG).show();
                                            }

                                        } else {
                                            //display some message here
                                            Toast.makeText(Registration.this, "Registration Error", Toast.LENGTH_LONG).show();
                                        }
                                        progressDialog.dismiss();
                                    }
                                    else{
                                        progressDialog.dismiss();
                                        Toast.makeText(Registration.this, "Enter an valid email id or account is already exist", Toast.LENGTH_LONG).show();
                                    }
                                }
                            });
                } else {
                    regcpass.setError("Password mismatching");
                    regcpass.requestFocus();
                }
            }
        });
    }
}