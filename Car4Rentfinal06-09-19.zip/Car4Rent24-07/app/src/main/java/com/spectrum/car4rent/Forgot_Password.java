package com.spectrum.car4rent;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;

public class Forgot_Password extends AppCompatActivity {
    private static final String TAG = "Forgot_PAssword";
    Button fgtback,fgtreset;
    EditText fgtemail;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        String bgcolor = "#1B1B6B";
        ActionBar actionBar = getSupportActionBar();
        actionBar.setBackgroundDrawable(new ColorDrawable(Color.parseColor(bgcolor)));
        this.getWindow().setStatusBarColor(Color.parseColor(bgcolor));
        setContentView(R.layout.activity_forgot__password);

        fgtback= findViewById(R.id.fgtback);
        fgtemail= findViewById(R.id.fgtemail);
        fgtreset= findViewById(R.id.fgtreset);
        fgtreset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FirebaseAuth.getInstance().sendPasswordResetEmail(fgtemail.getText().toString())
                        .addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                if (task.isSuccessful()) {
                                    Log.d(TAG, "Email sent.");
                                    Toast.makeText(getApplicationContext(),"Request is send to email", Toast.LENGTH_SHORT).show();
                                    inty();
                                }else{
                                    Toast.makeText(getApplicationContext(),"email id not found", Toast.LENGTH_SHORT).show();
                                    fgtemail.requestFocus();
                                }
                            }
                        });


            }
        });
        fgtback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                inty();
            }
        });
    }

    private void inty() {
        Intent gotologin=new Intent(Forgot_Password.this,Login.class);
        startActivity(gotologin);
        finish();
    }
}
